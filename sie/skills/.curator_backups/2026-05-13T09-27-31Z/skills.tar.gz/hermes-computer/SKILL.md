---
name: hermes-computer
description: "Build and extend hermes-web-computer — Go backend + Svelte 5 SPA tiling AI desktop. Covers architecture, tile development, Hermes agent integration, and migration from agent-os/bytebot/cua."
version: 1.0.0
category: devops
---

# Hermes-Computer Operations

## What It Is

hermes-web-computer is a **tiling AI desktop** where each tile is a Svelte 5 component backed by a Go handler. The layout engine manages split/resize/focus. Tiles communicate through a JSON-RPC multiplexer over WebSocket.

## Architecture

```
┌─────────────────────────────────────────────────────────────────────┐
│                     hermes-web-computer (THE SHELL)                 │
│                                                                     │
│  ┌──────────┐ ┌──────────┐ ┌──────────┐ ┌──────────┐ ┌──────────┐ │
│  │ Terminal │ │ Browser  │ │ Dashboard│ │ Voice    │ │ Code     │ │
│  │   Tile   │ │   Tile   │ │   Tile   │ │   Tile   │ │  Edit    │ │
│  └────┬─────┘ └────┬─────┘ └────┬─────┘ └────┬─────┘ └────┬─────┘ │
│       │             │            │             │             │      │
│       └─────────────┴────────────┴─────────────┴─────────────┘      │
│                            │                                        │
│                  WebSocket (JSON-RPC)                                │
│                            │                                        │
│              ┌─────────────▼─────────────┐                          │
│              │   Go Backend Multiplexer  │                          │
│              └─────────────┬─────────────┘                          │
└────────────────────────────┼────────────────────────────────────────┘
                             │
            ┌────────────────┼────────────────┐
            │                │                │
  ┌─────────▼──────┐ ┌──────▼──────┐ ┌──────▼──────┐
  │  hermes-agent  │ │  Docker     │ │  External   │
  │  (THE BRAIN)   │ │  Sandbox    │ │  APIs       │
  └────────────────┘ └─────────────┘ └─────────────┘
```

## Repo & Access

- **GitHub**: `github.com/ChonSong/hermes-web-computer` (branch: main)
- **Local**: `/opt/data/hermes-web-computer`
- **Planning**: `github.com/ChonSong/hermes-computer-planning`
- **Stack**: Go 1.25 + Svelte 5 + Vite + Tailwind + xterm.js

## Quick Start

```bash
# CRITICAL: Frontend build is in frontend/ subdirectory, NOT repo root
cd /opt/data/hermes-web-computer/frontend && npm run build

# Backend serves frontend static files from frontend/dist
cd /opt/data/hermes-web-computer/backend
go build -o /opt/data/hwc-server ./cmd/server/
PORT=3005 /opt/data/hwc-server

# Open http://localhost:3005
```

**Note:** Port 3001 is used by agent-os. Use `PORT=3005` for hermes-web-computer.

## Core Packages

| Package | Purpose | Status |
|---------|---------|--------|
| `ws/multiplexer.go` | JSON-RPC routing (ui/agent/audio/browser) | ✅ Working |
| `pty/supervisor.go` | PTY lifecycle, ring buffer, checkpoint | ✅ Working |
| `layout/tree.go` | Binary tree layout with delta ops | ✅ Working |
| `security/security.go` | YAML permissions, token-gated execution | ✅ Working |
| `telemetry/telemetry.go` | JSONL ring buffer, async sync | ✅ Working |
| `audio/bridge.go` | Fun-Audio-Chat binary protocol relay (Opus/Text/Interrupt) | ✅ Working |
| `browser/browser.go` | chromedp wrapper (navigate/screenshot/click/input/back/forward) | ✅ Working |
| `ws/filesystem.go` | FS handlers (list/read/write/stat/delete) with path sandboxing | ✅ Working |
| `ws/apps.go` | App launch handlers (terminal/editor/preview/browser) | ✅ Working |
| `ws/multiplexer.go` (routeUI) | Dashboard handlers (stats/analytics/system/observability) | ⚠️ Placeholder data |
| `hermes/adapter.go` | Hermes Agent integration (chat → API) | ✅ Working (chat.send) |
| `llm/router.go` | Multi-provider LLM routing | ❌ TODO |

## Tile Development

### Adding a New Tile

1. **Create Svelte component** in `frontend/src/components/`
2. **Wire to layout engine** — add content type to `LayoutTree`
3. **Add Go handler** in `backend/ws/multiplexer.go` (routeUI or routeAgent)
4. **Update security config** if tile needs privileged operations
5. **Add telemetry events** for tile-specific metrics

### Tile Template

```svelte
<script lang="ts">
  import { send, on } from "../stores/ws"

  let { tileId = "" }: { tileId?: string } = $props()
  let status = $state("idle")

  function handleAction() {
    send({
      protocol: "agent",
      method: "tile.action",
      params: { tile_id: tileId, action: "do_something" }
    })
  }

  // Listen for backend events (cleanup on destroy)
  let cleanupFns: (() => void)[] = []
  $effect(() => {
    cleanupFns.push(
      on("tile.action.result", (data: unknown) => {
        status = (data as { status?: string }).status ?? "error"
      })
    )
    return () => { cleanupFns.forEach(fn => fn()); cleanupFns = [] }
  })
</script>

<div class="w-full h-full bg-gray-950 text-gray-100 flex items-center justify-center">
  <button onclick={handleAction}>Do Something ({status})</button>
</div>
```

**Note:** Use `onclick` not `on:click` (Svelte 5). Use the store's `on()` function for WS events, not `window.addEventListener`.

## Current State Audit (2026-05-11)

### ✅ Fully Implemented (v1.0 + Illogical Impulse redesign)
- WS multiplexer (4 protocols: ui, agent, audio, browser) with read/write loops
- PTY supervisor with 1MB ring buffer, checkpoint, signal handling
- Layout tree (split/mount/unmount/resize/swap/fullscreen with delta ops)
- Security enforcer (YAML config, safe/prompt/block tiers, token gating)
- Telemetry JSONL ring buffer with auto-prune + async HTTP sync
- Audio bridge (Fun-Audio-Chat binary protocol: Opus relay, text, interrupt)
- Filesystem API (list/read/write/stat/delete with path sandboxing, base64 binary)
- App launcher (terminal/editor/preview/browser via PTY + chromedp)
- 4-column frontend (resizable, localStorage persistence, toggleable panels)
- Terminal tile (xterm.js + FitAddon)
- Monaco editor (read-only **with Ctrl+S save/write-back**, dirty indicator)
- File tree (expand, navigate, open files)
- App launcher (command palette for tile types)
- Agent chat UI → **Hermes Agent API** (RightPanel: message history, typing indicators, voice recording via MediaRecorder webm/opus)
- Browser tile (chromedp: navigate, screenshot, click, input, back/forward — screenshot-based viewport)
- 5 Dashboard tiles migrated from agent-os React → Svelte 5:
  - DashOverview (KPI cards, session analytics, event breakdown)
  - DashFileManager (browse, preview, edit, create, delete files)
  - DashSystemStatus (system info, CPU/mem/disk, service status)
  - DashAnalytics (token usage, daily breakdown, model/skill tables)
  - DashObservability (AI event feed, filters, status indicators)
- Command palette (Ctrl+K), Keymap overlay (Ctrl+?)
- **Illogical Impulse glassmorphism redesign:**
  - CSS tokens, Tailwind config with `@theme`, gradient background
  - Floating translucent panels with `backdrop-blur-2xl`, `rounded-2xl`
  - WorkspacePill (top-center, workspace 1-9 dots), Dock (bottom-center, app icons)
  - Monaco dark theme matching purple/violet palette
  - Custom scrollbars, pulseGlow animations
- **Workspace system:** 9 workspaces, each with independent layout tree + floating tiles
- **Full keyboard shortcut map:** Shift+Arrow, Shift+D, Shift+F, Shift+Q, Shift+Alt+Arrow, Shift+Space, Shift+1-9
- **Drag-and-drop:** FileTree → RightPanel (agent context), FileTree → MiddlePanel (editor open)
- **Agent context awareness:** Backend tracks focused tile, provides context scoping
- 10 E2E Playwright tests (Illogical Impulse UI — all passing)
- 17+ Playwright E2E tests (layout, resize, chaos, a11y, perf, workflows)
- 45+ Go backend unit/integration tests (all passing)

### ❌ Not Started
- **fs.watch** — Marked as "future" in PLAN.md.
- **Dashboard tile** backend handlers — Return placeholder data (stats, analytics, system info). Need to wire to real telemetry/docker/sysinfo sources.
- **LLM router** — `llm/router.go` is unimplemented (routing to multiple LLM providers).

### Pending Features (Phase Engine — Running as of 2026-05-13)

Phase engine cron job `9ed5a5ab3dc4` is running every 30min via `minimax-portal` provider. 8 phases total. See `/opt/data/project-state/hermes-web-computer/PHASE_TRACKER.json` for current status.

State machine at `/opt/data/project-state/hermes-web-computer/`:
```
PHASE_TRACKER.json      ← current phase, status, checkpoints
CHECKPOINTS/            ← completion records per phase
PROGRESS/               ← running progress
```

**Phase 1:** `tool.execute` wired to Hermes Agent API — the TODO stub at `backend/ws/multiplexer.go:567` needs replacing with real HTTP call to the Hermes Agent tool API (`localhost:8080/api/tool/execute` or hermes-agent CLI)
- **Phase 2:** `apps.list`/`apps.launch` fully wired — returns registered app types, creates PTY/editor tiles
- **Phase 3:** Fun-Audio-Chat voice bridge — actual audio relay in `backend/audio/bridge.go`
- **Phase 4:** Layout engine unit tests — `backend/layout/tree_test.go`
- **Phase 5:** GitHub Actions CI workflow — `.github/workflows/ci.yml`
- **Phase 6:** Pre-commit hooks — `.husky/pre-commit`
- **Phase 7:** Bundle size optimization — Monaco is 3.7MB chunk, needs code-splitting
- **Phase 8:** Final integration polish + v1.2 tag

### Recommended Build Order (Post-v1.0)
1. tool.execute integration (1-2d) — wire to Hermes Agent tool API
2. Dashboard backend → real data sources (1d) — wire stats/analytics to telemetry ring buffer, system info to os/syscall
3. fs.watch implementation (2-3d) — inotify-based file watching
4. Browser tile enhancements — full-page scroll, JS eval results overlay
5. New tiles: Code editor (full IDE), Git viewer, System monitor

### Subagent Timeout Pattern

When using `delegate_task` for multi-file Svelte + Go changes, subagents **consistently hit the 600s timeout** even after completing all file writes. The timeout means "didn't finish summarizing", not "didn't finish coding".

**Always check the filesystem after a subagent timeout:**
```bash
cd /opt/data/hermes-web-computer && git status --short
```
If files are modified or new files exist, the work is done. Review diffs, fix any issues, and commit. Don't re-run the task.

**Pattern observed:** Subagents make 20-40 API calls, modify 6-16 files, then time out. The code changes are always complete; the summary/response generation is what times out.

### Workspace Store with localStorage Persistence

The workspace system uses a Svelte writable store that auto-saves to localStorage:

```typescript
import { writable, get } from "svelte/store"

export const workspaceStore = writable<WorkspaceState>(initialState)

// Auto-save on every change
workspaceStore.subscribe((state) => {
  try {
    localStorage.setItem("hwc-workspaces-v1", JSON.stringify(state))
  } catch {}
})

// In components, use $derived for reactivity:
let wsState = $derived($workspaceStore)  // NOT let $ws = $state(...)
```

**Critical:** Never use `$` prefix for variable names (e.g., `let $ws = ...`) — Svelte 5 reserves `$` for runes and store subscriptions. Use `let wsState = $derived($workspaceStore)` instead.

### Persistent Phase Engine for Large Feature Work

For completing multiple remaining features (tile animations, workspace persistence, agent output drag, Lighthouse audit), use the **Persistent Phase Engine** pattern from the `autonomous-cron-pipeline` skill:

1. State directory: `/opt/data/project-state/hermes-web-computer/`
2. Tracker: `PHASE_TRACKER.json` with phase status and checkpoints
3. Cron job runs every 30m, reads tracker, executes next pending phase
4. Each phase commits independently — progress survives timeout
5. Checkpoints written to `CHECKPOINTS/phase-{id}-complete.md`

This pattern survives context compaction, session timeouts, and agent restarts. See `autonomous-cron-pipeline` skill for full architecture.

## Migration Strategy

### From agent-os (React → Svelte 5)

1. Use repo-transmute v2 to extract component blueprints
2. Migrate top 3 pages first: Agent Status, Session History, System Metrics
3. Wire migrated tiles to Go backend (replace Express API routes)
4. Test with vision verification

### From bytebot (Browser Tile)

1. Extract screenshot capture + DOM analysis components
2. Migrate TS→Go (backend handlers), TS→Svelte 5 (browser viewer)
3. Integrate with Go sandbox manager

### From cua (Sandbox Tile)

1. Extract screen capture + input routing components
2. Migrate Python→Go (system calls)
3. Adapt for Linux/Docker (cua is macOS-focused)

## Key Protocols

### JSON-RPC Envelope

```json
{
  "protocol": "ui|agent|audio",
  "method": "layout.update|pty.write|tool.execute|...",
  "params": {...},
  "id": "request_id",
  "ts": 1234567890
}
```

### Server Events

```json
{
  "protocol": "ui|agent|audio",
  "event": "layout.delta|pty.output|approval.required|...",
  "data": {...},
  "ts": 1234567890
}
```

### Layout Operations

| Op | Description |
|----|-------------|
| `split` | Convert leaf to split with two children |
| `mount` | Add new leaf to tree |
| `unmount` | Remove leaf, merge with sibling |
| `resize` | Change relative size of child |
| `swap` | Swap positions of two leaves |
| `fullscreen` | Toggle fullscreen for leaf |

### Keyboard Shortcuts

| Shortcut | Action |
|----------|--------|
| `Cmd/Ctrl+K` | Command palette |
| `Cmd/Ctrl+?` | Keymap overlay |
| `Shift+Arrow` | Focus adjacent tile |
| `Shift+Alt+Arrow` | Resize tile borders |
| `Shift+D` | Cycle layout modes (master-stack, even-split, columns, rows) |
| `Shift+F` | Toggle fullscreen on focused tile |
| `Shift+Q` | Close focused tile |
| `Shift+Space` | Toggle floating/tiled mode on focused tile |
| `Shift+1-9` | Switch workspace (each workspace has independent layout tree) |
| `Shift+Alt+1-9` | Move focused tile to another workspace (toggles floating mode) |
| `Ctrl+B` | Toggle left panel |
| `Ctrl+Shift+B` | Toggle right panel |

## Docker Compose

```yaml
services:
  agent-os:
    build: ../backend
    ports: ["3001:3001"]
    networks: [agent-net]
    volumes:
      - ../state:/agent/.state
      - ../telemetry:/agent/.telemetry

  hermes:
    image: nousresearch/hermes-agent:latest
    network_mode: host

  fun-audio:
    build: ../bridge
    network_mode: host
    deploy:
      resources:
        reservations:
          devices:
            - driver: nvidia
              count: 1
              capabilities: [gpu]

  caddy:
    image: caddy:latest
    ports: ["80:80", "443:443"]
    volumes:
      - ./Caddyfile:/etc/caddy/Caddyfile
      - ../frontend/dist:/srv/frontend
```

## Validation Criteria

| Component | Metric | Target |
|-----------|--------|--------|
| Layout Engine | p99 layout render | <50ms |
| Security | Blocked `rm -rf` halts + red border | Works |
| Telemetry | Events written + synced | Works |
| Tile Engine | Recursive layout, keyboard nav, border states | Works |
| Audio Bridge | Opus relay + interrupt | Works |
| Integration | `docker compose up` → full flow | Works |
| Interrupt | Shift+Space to amber border | <100ms |

## Pitfalls

- **PTY output flow** — Must forward to both ring buffer AND output channel
- **Security default** — Default to "safe" tier, not "block"
- **Static file serving** — Check absolute path first to avoid stale dist dirs
- **Svelte 5 syntax** — `onclick` not `on:click`, `$props()` not `export let`, `$state()` not `$:`
- **Svelte 5 `{/* */}` comments** — Svelte 5.55+ fails to compile `{/* */}` in template sections. Use `<!-- -->` or strip them.
- **Tailwind v4 config** — Uses CSS-based `@theme` directive in `frontend/src/styles/glass.css`, NOT `tailwind.config.js`. Add custom colors, shadows, animations via `@theme` block in CSS.
- **Illogical Impulse design system** — Glassmorphism theme: `backdrop-blur-xl bg-[#12121a]/90 border-white/10 rounded-2xl shadow-panel`. Active tiles get `border-glass-border-active ring-1 ring-purple-500/20`. Workspace pill (top-center), floating dock (bottom-center). Full spec: `ILLOGICAL-IMPULSE-DESIGN.md` in planning repo.
- **AGENTS.md pattern** — Every repo in the ecosystem should have an `AGENTS.md` for AI agent consumption: what it is, key files, quick commands, integration points. Create alongside README rewrites.
- **Svelte 5 `$state(prop)` anti-pattern** — Can't initialize `$state()` with a prop. Use `$state("")` + `$effect(() => { val = prop })`.
- **Svelte 5 handler param naming** — Don't name handler params the same as `$state` variables (causes shadowing).
- **Subagent timeouts** — Subagents complete code changes but timeout before commit. Always `git status --short` after timeout — work is on disk.
- **WebSocket routing** — Route ordering matters: `/ws` before `/`
- **Layout tree** — Max depth 3, lazy-mount Monaco/xterm on viewport entry
- **Path sandboxing** — `sanitizePath()` strips leading `/` and joins with `allowedRoot`. Even `/etc/shadow` becomes `allowedRoot/etc/shadow`. Only `../` traversal is rejected. Tests MUST verify this behavior.
- **Playwright selectors** — Avoid `getByText('Agent')` strict mode violations (matches multiple elements). Use `getByRole('heading', {name:'Agent'})` or `getByRole('textbox', {name:'Type a message...'})` for unique selectors.
- **Integration test timeouts** — WebSocket tests on httptest need 15-30s context timeouts, not 5s. PTY startup adds latency.
- **Go test mock sessions** — Use `drainEvents(sess)` helper that reads from `sess.send` channel (buffered, non-blocking) instead of trying to intercept `Send()` calls.
- **Go `write_file` lint false-positive** — When creating Go files in the ws/ package, the linter may report `undefined: Multiplexer` even though `go build` succeeds. This is a linter bug in the file write context. Always verify with `go build ./...` and `go vet ./...` — if those pass, the file is correct.
- **Layout pty_id location** — `layout.initial` event nests `pty_id` inside `data.tree.pty_id`, not at root level. Integration tests must assert this structure.
- **Svelte 5 duplicate script blocks** — If a merge or subagent creates a second `<script>` block after `</style>`, the build fails with `error TS2591: script_duplicate`. Fix by removing the second block entirely and ensuring all variables live in the first `<script lang="ts">` at the top of the file.
- **Layout state persists across WebSocket connections** — The `m.layout` object in `multiplexer.go` is a shared singleton. When a browser connects and splits the layout, `m.layout` becomes a split. When a new browser connects (or the same browser reconnects), `m.layout` is still a split, so trying to split again fails with "cannot split a split node". **Fix:** Reset `m.layout = layout.NewRoot("xterm")` at the start of each new WebSocket session in `HandleWebSocket`.
- **Browser tile requires Chromium** — On Linux, the browser tile needs `chromium` installed. The backend looks for `google-chrome` in `$PATH` by default. Set `CHROMIUM_PATH=/usr/bin/chromium` env var when starting the server. Install with `apt-get install -y chromium`.
- **browser_id propagation in layout tree** — When a browser tile is launched, `apps.launch.response` returns a `browser_id`. This must flow through `layout.update` (split/mount op) into the `LayoutTree.BrowserID` field. Without it, the Browser.svelte component has no CDP endpoint to connect to. Ensure `BrowserID` is copied in `applySplit` and `applyMount` in `tree.go`, and passed in the frontend's `layout.update` message.
- **WebSocket debug logging pattern** — For debugging event flow across Svelte modules, use `globalThis` with a type assertion to store event arrays: `const win = globalThis as typeof globalThis & { __wsEvents?: Event[] }; if (!win.__wsEvents) win.__wsEvents = []; win.__wsEvents.push(event)`. This avoids TypeScript `window.__wsEvents` errors. Access from browser console as `window.__wsEvents`.
- **Debug WebSocket event handler registration** — Add logging to the `on()` function to confirm handlers are registered: `console.log('[WS] Handler registered for', event, 'total:', handlers.get(event)?.size)`. This reveals if event names don't match between send and receive.
- **hermes-computer rebuild cron** (`ecb3846b907b`) was failing — `npm run build` from repo root fails because the frontend build is `frontend/` not root. Fixed 2026-05-13: changed rebuild command to `cd frontend && npm run build`. Phase engine (`9ed5a5ab3dc4`) handles completion phases separately.

## Testing

### Backend (Go)

45+ tests across filesystem handlers, app protocol, WebSocket integration, layout engine, security, and benchmarks.

```bash
cd backend && go test ./... -count=1 -timeout=120s
```

Key patterns:
- `mockSession` with buffered `send` channel + `drainEvents()` for event capture
- `setupTestServer()` + `connectWS()` for integration tests
- `readEventsUntil()` with context timeouts for async WebSocket responses
- `sanitizePath` tests verify path sandboxing (not rejection) for absolute paths

## E2E Testing (Playwright)

17+ Playwright tests across 6 categories (Chromium only).

```bash
npx playwright test e2e/tests/01-layout.spec.ts  # single test
npx playwright test e2e/tests/workflows/          # workflow suite
```

Config: `playwright.config.ts` with auto-start Go backend via `webServer`.

### Test Categories

| Category | Files | Description |
|----------|-------|-------------|
| Functional | `01-layout`, `02-resize` | Layout renders, column resizing |
| Workflows | `workflows/*.spec.ts` | File edit, multi-terminal pipeline, chat context, session recovery, cross-panel |
| Chaos | `chaos/*.spec.ts` | Concurrent tabs, server disconnect recovery |
| A11y | `a11y/keyboard.spec.ts` | Tab navigation, focus rings, keyboard shortcuts |
| Visual | `visual/baseline.spec.ts` | Baseline screenshots for regression |
| Perf | `perf/load-time.spec.ts` | TTFB, DCL, paint timings, bundle size |

### Selector Cheat Sheet

| Target | Selector | Why |
|--------|----------|-----|
| Terminal tile | `div.border-blue-500` | Unique border class on Tile component |
| Left panel tabs | `getByRole('button', { name: 'Files' })` | ARIA button |
| Agent heading | `getByRole('heading', { name: 'Agent' })` | Avoids strict mode violation (getByText matches 3 elements) |
| Chat input | `getByRole('textbox', { name: 'Type a message...' })` | Distinguishes from xterm textarea |
| Resize handles | `.cursor-ew-resize` | Unique class on ResizeHandle |
| Main container | `div.h-screen` or `.bg-gray-950` | Root layout div |

### Common Pitfalls

- `getByText('Agent')` strict mode violation — matches "Agent-OS v1.2", "Agent" heading, and agent message text. Use `getByRole('heading', {name:'Agent'})` instead.
- `getByRole('textbox')` strict mode violation — matches both xterm helper textarea and chat input. Use specific `name` param.
- `div[tabindex="0"]` doesn't match — Tile uses `border-blue-500` class for identification, not tabindex.
- Disconnected state test: page connects immediately on server start, so "Disconnected" state is never visible. Test the connected state instead.
- Baseline visual tests: use `--update-snapshots` after intentional UI changes.
- Concurrent tab tests: use `context.newPage()` to open tabs in same browser context.
- Chaos server-death test: use `test.skip()` since `webServer` manages the lifecycle. Test disconnect via `context.setOffline()` instead.

### Bulk Selector Fix

When selectors need updating across multiple test files:
```bash
sed -i 's/div\[tabindex="0"\]/div.border-blue-500/g' e2e/tests/workflows/*.spec.ts
```

## Related Skills

- `repo-transmute` — Migration engine for converting repos to tiles
- `hermes-agent` — Hermes Agent configuration and usage
- `svelte-development` — Svelte 5 development patterns

## References

- `references/illogical-impulse-tokens.md` — Illogical Impulse design tokens: colors, glassmorphism patterns, Tailwind @theme config, component class patterns
- `references/component-dependencies.md` — Full dependency map, per-tile backend/frontend requirements, WS protocol extensions
- `references/browser-tile-debugging.md` — Browser tile debug session: app type mismatch root cause, browser_id propagation flow, WebSocket message sequence, Chromium setup, debug console commands
- `references/testing-patterns.md` — Go backend testing patterns
- `references/playwright-tests.md` — E2E test config, categories, run commands
- `references/playwright-selectors.md` — Selector cheat sheet, common pitfalls, bulk fix patterns
