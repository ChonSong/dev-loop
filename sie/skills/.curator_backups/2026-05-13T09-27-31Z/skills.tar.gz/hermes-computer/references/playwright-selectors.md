# Playwright Selector Patterns for hermes-web-computer

## Selector Cheat Sheet

| Target | Selector | Why |
|--------|----------|-----|
| Terminal tile | `div.border-blue-500` | Unique border class on Tile component |
| Left panel tabs | `getByRole('button', { name: 'Files' })` | ARIA button |
| Agent heading | `getByRole('heading', { name: 'Agent' })` | Avoids strict mode violation |
| Chat input | `getByRole('textbox', { name: 'Type a message...' })` | Distinguishes from xterm textarea |
| Resize handles | `.cursor-ew-resize` | Unique class on ResizeHandle |
| Main container | `div.h-screen` or `.bg-gray-950` | Root layout div |
| Disconnected state | `getByText('Disconnected')` | Only visible when WS is down |

## Common Pitfalls

### Strict Mode Violations

Playwright's `getByText` and `getByRole` fail when multiple elements match.

**BAD:**
```typescript
await expect(page.getByText('Agent')).toBeVisible()
// Fails: matches "Agent-OS v1.2", "Agent" heading, and agent message text
```

**GOOD:**
```typescript
await expect(page.getByRole('heading', { name: 'Agent' })).toBeVisible()
```

### Terminal Tile Selector

The Tile component uses `border-blue-500` class, NOT `div[tabindex="0"]`.

**BAD:**
```typescript
page.locator('div[tabindex="0"]')  // Doesn't match
```

**GOOD:**
```typescript
page.locator('div.border-blue-500')  // Matches terminal tiles
```

### Disconnected State

The server auto-connects immediately, so "Disconnected" state is never visible in normal test runs. Don't test for it — test for the connected state instead.

### Bulk Selector Fixes

```bash
# Fix all workflow test selectors at once
sed -i 's/div\[tabindex="0"\]/div.border-blue-500/g' e2e/tests/workflows/*.spec.ts
```

## Test Categories

| Category | Files | Frequency |
|----------|-------|-----------|
| Functional | `01-layout`, `02-resize` | Every commit |
| Workflows | `workflows/*.spec.ts` (5 files) | Every commit |
| Chaos | `chaos/concurrent.spec.ts` | Every commit |
| A11y | `a11y/keyboard.spec.ts` | Every commit |
| Visual | `visual/baseline.spec.ts` | Every commit |
| Perf | `perf/load-time.spec.ts` | Every commit |

## Running Tests

```bash
# Single test
npx playwright test e2e/tests/01-layout.spec.ts

# Suite
npx playwright test e2e/tests/workflows/

# All tests
npx playwright test --reporter=list

# Update visual baselines
npx playwright test e2e/tests/visual/ --update-snapshots
```

## Config

Browser: Chromium only (not Firefox/WebKit). This is a local dev tool, not a consumer website.

```typescript
// playwright.config.ts
export default defineConfig({
  testDir: './e2e/tests',
  fullyParallel: false,
  timeout: 30000,
  workers: 1,
  projects: [{ name: 'chromium', use: { browserName: 'chromium' } }],
  webServer: {
    command: 'cd backend && go run ./cmd/server',
    port: 3005,
    reuseExistingServer: true,
  },
})
```
