# Cron Delivery Failures — Lessons from OpenClaw

**Source:** OpenClaw session log analysis (82 sessions) + Hermes cron audit  
**Date:** 2026-04-30

---

## The Core Pattern: Output Produced, Delivery Silent

Both Night Owl (OpenClaw) and Overnight Autonomy Engine (Hermes) produced valuable output that **never reached Sean**:

```
[Agent Runs] → [Output Generated] → [Delivery Fails] → [Human Awareness: ZERO]
```

The agent treats delivery failure as non-fatal and continues the next scheduled run. The human is unaware anything happened.

---

## Night Owl (OpenClaw) — Full Silent Failure

| Attribute | Value |
|-----------|-------|
| Frequency | Every 30 min, 1–7pm Sydney (12 runs/night) |
| Output | 17KB detailed markdown reports |
| Delivery attempt | Telegram webhook |
| Delivery result | Every run: `"Delivering to Telegram requires target <chatId>"` |
| Human awareness | Zero — Sean never saw a single report |
| What it found | Exposed Gmail password, GitHub PATs, identity conflicts — all silently |

The `chatId` was never configured. The job ran successfully every time (exit 0), produced rich output, and then silently died at the delivery step.

---

## Overnight Autonomy Engine (Hermes) — False-Positive OK

| Attribute | Value |
|-----------|-------|
| Cron schedule | `0 15 * * *` (3pm Sydney) |
| Execution | `cd /home/sean/workspace && python3 scripts/overnight_engine.py` |
| Script path | **Does NOT exist in container** |
| Delivery | `deliver: local` |
| Cron status | `last_status: ok` ← **FALSE POSITIVE** |

The `ok` means "the cron scheduler ran without throwing an exception." It does NOT mean Sean received anything. The script path doesn't exist, so either the job produces no output, or the output goes somewhere no one checks.

---

## The Two Failure Modes

| Mode | Symptom | Detection |
|------|---------|-----------|
| **Delivery broken** | Job runs (`last_run_at` updates), but delivery fails (`last_delivery_error` set) | Check `last_delivery_error` |
| **Never runs** | `last_run_at: null` despite being scheduled | Check `last_run_at` |

Both produce `last_status: ok` in the normal case. Neither is sufficient to know if Sean actually received the output.

### Failure Mode 4: Discord 401 — "Empty Response" Misdiagnosis

**Symptom:** `last_status: error` with `"Agent completed but produced empty response (model error, timeout, or misconfiguration)"` — but the agent ran and produced text. The real error is HTTP 401 Unauthorized from Discord.

**Root cause:** A cron job using the Discord messaging adapter hits Discord's API with a missing or invalid `DISCORD_BOT_TOKEN`. The HTTP 401 propagates as a model-level error, completely masking the actual API failure.

**Detection:**
```
# Check gateway log for 401
grep "401\|Unauthorized\|discord" ~/.hermes/logs/gateway.log | tail -10

# Verify token is set
env | grep DISCORD_BOT_TOKEN   # should return a long token string
grep DISCORD_BOT_TOKEN ~/.hermes/.env
```

**Fix:** Add `DISCORD_BOT_TOKEN=your_token` to `~/.hermes/.env`, then restart gateway.

**Why it's insidious:** The job's `last_error` gives no indication it's a Discord issue. Every subsequent run produces the same misleading error. The job appears broken at the model level when the model is fine — it's the delivery channel that's misconfigured.

**Also check:** The target channel must be in `allowed_channels` in config.yaml under the `discord:` section.

---

### Failure Mode 3: Model Error → Empty Deliverable

**Symptom:** `last_status: error` with `"Agent completed but produced empty response (model error, timeout, or misconfiguration)"` — but the agent actually ran successfully and produced text, which then got discarded during post-processing (summarization or title generation).

**Root cause:** MiniMax API returns `code: 1211 Unknown Model` when hermes-agent calls it for session summarization or title generation. The main agent loop completes, but the post-processing step fails silently, leaving an empty deliverable.

**Detection:**
```bash
grep "1211\|Unknown Model\|Session summarization failed\|Title generation failed" ~/.hermes/logs/agent.log
```

**See:** `references/minimax-api-failures.md` for full diagnosis and workarounds.

---

## The Diagnostic Pattern

```python
# Check if job has ever run
if job['last_run_at'] is None:
    print(f"⚠️  {name}: Never run — check schedule format, skill loading, script path")
    
# Check if delivery succeeded  
if job['last_delivery_error']:
    print(f"❌ {name}: Delivery failed — {last_delivery_error}")

# Even with no error, check WHERE output went
if job['deliver'] == 'local':
    print(f"⚠️  {name}: deliver=local — output stored, not pushed to Sean")
```

---

## The Non-Negotiable Rule

```
IF a cron job's output is intended for human consumption:
  THEN "deliver: local" is NOT acceptable
  THEN delivery MUST be tested before scheduling
  THEN "last_status: ok" is NOT sufficient verification
  THEN verify: did Sean actually receive this?
```

**Test delivery in the same session that configures the job:**
1. Write the prompt
2. Force-run once immediately (`hermes cron run <job_id>`)
3. Verify output reaches the intended destination
4. Then enable the schedule

---

## Current Hermes Cron Jobs — Delivery Risk Assessment

| Job | Delivery | Risk |
|-----|----------|------|
| Night Owl Report | local | ❌ Never run |
| Memory Curation | local | ⚠️ Output not pushed |
| Morning Briefing | local | ❌ Never run |
| Cross-Agent Bridge Poll | local | ⚠️ Output not pushed |
| System Monitor & Cleaner | local | ⚠️ Output not pushed |
| HKUDS/ClawTeam Daily | local | ⚠️ Output not pushed |
| Delegation Monitor | local | ⚠️ Output not pushed |
| Autonomy Digest | local | ⚠️ Output not pushed |
| Infrastructure Daily | local | ⚠️ Output not pushed |
| Rate Smoother Backoff | local | ⚠️ Output not pushed |
| **Overnight Autonomy Engine** | local | ❌ Script path dead, false OK |
| Hermes Sync — GitHub Push | local | ❌ Never run |
| hermes-sync rolling rebuild | local | ❌ Never run |

**Pattern:** Every single job uses `deliver: local`. None push output to Sean directly.

---

## What Good Delivery Looks Like

For a morning briefing system:
- Output queued to a format Sean reads (email, Telegram, morning briefing aggregation)
- Critical findings (disk >95%, security issues, agent crashes) trigger immediate escalation
- Routine status goes into the daily digest

For an overnight engine:
- Summary of what was accomplished pushed to Sean's morning briefing
- Any blocking issues flagged immediately
- Full logs stored locally for debugging

---
