---
name: roadmap-engine
description: "Roadmap Autonomy Engine — long-horizon autonomous planning and execution system. Runs nightly: Phase 1 research (clone/scan/revise roadmap.json), Phase 2 execute (test/code/research/review/browser tasks until 14:00 UTC), Phase 3 report (narrative + Telegram critical issues)."
---

# Roadmap Autonomy Engine

Long-horizon autonomous planning and execution system. Runs a nightly session cycle that revises a persistent `roadmap.json` (top-down goals + bottom-up discovery), executes tasks across 5 productivity dimensions, and reports to morning briefing.

## Directory Structure

```plaintext
hermes-sync/scripts/
├── roadmap_engine.py       # Main entry point (Phase 1+2+3 runner)
├── roadmap.py               # Data model + roadmap CRUD
├── reporters.py             # Phase 3 narrative report generator
├── planner.py               # LLM-driven task planning (stub)
├── executor.py              # Task execution (stub — test type works)
├── research.py              # Discovery-driven bottom-up idea generation (stub)
├── self_improvement.py      # Self-improvement loop entry point
└── learnings_scanner.py     # Scan learnings → rank skill candidates
└── skill_author.py          # Author SKILL.md from high-priority candidates
```

```
hermes-sync/workspace/plans/
├── roadmap.json           # Single source of truth (seeded with 4 projects)
└── roadmap-history/        # Per-session snapshots
```

## Roadmap Schema (`roadmap.json`)

| Field | Purpose |
|-------|---------|
| `goals[]` | Top-down objectives (set by Sean or reverse-engineered from priorities) |
| `projects[]` | Repos with metadata (name, path, url, status, priority) |
| `tasks[]` | Executable work items: status, priority, effort, skills_required, type |
| `ideas[]` | Voted on; promoted to tasks at 3+ votes |
| `learnings[]` | Findings that persist across sessions |
| `blockers[]` | Known external dependencies |
| `activity_log[]` | Per-session history |

## Task Types (Executor)

| Type | Status | Approach |
|------|--------|----------|
| `test` | ✅ Working | Run pytest in repo; if 0 tests collected, spawn coder subagent |
| `code` | ✅ Working | TDD cycle: write tests → hermes chat coder → apply diff → commit |
| `research` | ✅ Working | Spawn hermes chat with web toolset; findings saved to plans/research-* |
| `browser` | ✅ Working | Spawn hermes chat -t browser for web automation tasks |
| `review` | ✅ Working | Spawn hermes chat; review saved to plans/review-* |

## Phase Cycle

```
Phase 1 RESEARCH (30-60 min):
  Clone/pull repos → scan TODOs/FIXMEs → GitHub issues → CI failures
  → self-improvement scan (learnings → high-priority skill candidates)
  → LLM planner revises roadmap.json → snapshot to roadmap-history/
```
Phase 2 EXECUTE (until 14:00 UTC / midnight Sydney):
  Load top tasks → verify preconditions → execute via appropriate executor
  → record results → update roadmap → commit hermes-sync changes

Phase 3 REPORT (15-30 min):
  Generate narrative report → critical issues to Telegram → rest to morning briefing
  → push roadmap.json + report to git
```

## Known Failure Modes (Quality Gap Analysis)

Identified 2026-05-01 — these are systemic limitations, not bugs:

1. **No task decomposition** — "Add test suite for X" is one task handed to a subagent whole. Should be: identify public APIs → smoke test → edge cases → verify coverage. Engine doesn't decompose.

2. **No context injection** — ~~Coder subagent gets `task['description']` only.~~ **FIXED** ✅ — `_build_coder_context()` now injects source files, test patterns, and project config into coder prompts.

3. **No quality gates** — ~~A test that fails to compile still commits.~~ **FIXED** ✅ — lint gate (ruff) runs before commit; blocks + reverts on failure.

4. **No iteration** — First attempt fails → engine records a learning and moves on. No retry with feedback.

5. **No cross-task intelligence** — Tasks execute in isolation. If task-A changes an API task-B depends on, task-B fails without engine noticing.

## Self-Improvement Loop (Phase 1)

Phase 1 now closes the loop on its own learnings — errors and corrections get turned into reusable skills automatically.

### Pipeline

```
Phase 1
  └── _run_self_improvement()
        ├── learnings_scanner.py   → skill_candidates.json (scored + ranked)
        └── skill_author.py        → SKILL.md authored → committed to hermes-sync
```

### Scoring formula

```
skill_score = priority_weight × area_multiplier × type_weight × recurrency × recency
```

| Signal | Effect |
|--------|--------|
| High priority (priority=high) | ×1.5 |
| Infrastructure area | ×1.3 |
| Implementation error type | ×1.2 |
| Recurring 3+ times | ×1.5 (recurrency multiplier) |
| Recent (<7 days old) | ×1.2 |

**Authoring threshold:** `score ≥ 50` OR `recurrences ≥ 3`

### What triggers a skill

| Candidate source | Example |
|-----------------|---------|
| `hermes-sync/workspace/plans/roadmap-learnings/` | Error patterns, fix recipes |
| `memory/` (parsed via session_search) | Repeated corrections or workflow issues |
| `skills/*/SKILL.md` (audit) | Missing coverage, gaps in existing skills |
| `hermes-sync/scripts/*` log traces | Patterns in stderr/stdout |

### What gets authored

- SKILL.md with: title, trigger condition, numbered steps, pitfalls
- References link back to the candidate ID that triggered it (full traceability)
- Committed to `hermes-sync/skills/<category>/<skill-name>/`
- Skill author hooks into `skills/` tool so future sessions load it automatically

### Skill lifecycle

```
detected (score < threshold) → tracked (score grows with recurrence)
    → authored (threshold met) → loaded (next applicable session)
    → used → corrected → tracked again (updated via patch)
```

### Key files

| File | Role |
|------|------|
| `scripts/self_improvement.py` | Orchestrator: runs scanner → skill_author pipeline |
| `scripts/learnings_scanner.py` | Scans 4 sources, scores candidates, writes `skill_candidates.json` |
| `scripts/skill_author.py` | Reads candidates, researches, authors SKILL.md, commits |

## Immediate Fixes (Highest Leverage)

### Fix 1: Context injection for coder subagent ✅ IMPLEMENTED

- `_build_coder_context()` injects: target source file, existing test patterns (first 2), project config files (pyproject.toml, setup.py, package.json, ruff.toml, mypy.ini), task overview
- Wired into both test and implement prompt calls in `_execute_code`
- Coder subagent now sees actual source code instead of flying blind

### Fix 2: Quality gate before commit ✅ IMPLEMENTED

- `ruff check .` runs after diff application, before commit
- On lint failure: patch is reverted via `git checkout -- .`, returns `status: "failed_qa"`, no commit made
- `python` variable hoisted outside test conditional so lint gate can use it

### Fix 3: Task decomposition in Phase 1

Planning subagent should decompose multi-step tasks automatically:
- "Add test suite for translator.py" → task-001a (identify APIs), task-001b (smoke tests), task-001c (edge cases), task-001d (coverage verify)

## Short-Term Improvements (This Week)

- **Docker isolation per project** — run code/test tasks in containers (python:3.11 for repo-transmute, node:20 for everything-dashboard)
- **CI signal reader in Phase 1** — read GitHub Actions API for last 5 workflow runs, create tasks from failures automatically
- **Multi-source research** — research tasks should do: web search + file analysis + GitHub issues + synthesis (not single hermes chat call)

## Medium-Term (CI/CD Pipeline Integration)

- Add GHA `path:` filters per project in hermes-sync
- Add `semantic-release` with conventional commits (`feat:`, `fix:`)
- Add quality gate job: lint → test → type-check → audit
- Wire `on.check_run` webhook to update `roadmap.json` with CI results
- Consider Nx/Turborepo monorepo for shared tooling across projects

## Key Implementation Facts

- **Hermes binary:** `/opt/hermes/.venv/bin/hermes`
- **Available toolsets:** `browser`, `cronjob`, `file`, `session_search`, `skills`, `terminal`, `web`
- **GitHub token:** `~/.netrc` with PAT — handled natively via urllib
- **xvfb-run:** `/usr/bin/xvfb-run` (for headless GUI tasks)
- **Browser:** Use `browser-agent` skill — **do NOT install standalone Playwright/Selenium**
- **Hermes runs in a container:** PID 1 is `/usr/bin/tini -g -- /opt/hermes/docker/entrypoint.sh gateway run` — hermes-agent itself runs inside a Docker container (Debian/Arch host). This has implications:
  - Docker-in-Docker does NOT work — the container lacks `CAP_NET_ADMIN` (iptables fails with "permission denied")
  - `dockerd` is not installed in the container — only the `docker` CLI is present
  - Docker socket is not mounted in — no access to host Docker daemon via `/var/run/docker.sock`
  - Deployments requiring Docker must use **GitHub Actions SSH deploy** pattern (build in GHA → SSH to server → `docker compose up`)
  - Host Docker API sometimes reachable at `http://172.17.0.1:2375` if host has Docker exposed, but often firewalled

## Agent-OS Deployment (SSH Deploy Pattern)

When deploying agent-os from hermes-agent (which can't run Docker directly):

1. **Generate ED25519 deploy key:** `ssh-keygen -t ed25519 -C "github-actions@agent-os" -f /tmp/github_actions_deploy -N ""`
2. **Add public key to server:** `echo "$(cat /tmp/github_actions_deploy.pub)" >> ~/.ssh/authorized_keys` on target server
3. **Store private key as GitHub secret:** `gh secret set DEPLOY_SSH_KEY -R ChonSong/agent-os < /tmp/github_actions_deploy`
4. **Store server IP as secret:** `gh secret set DEPLOY_HOST -R ChonSong/agent-os`
5. **Workflow lives in:** `.github/workflows/build-and-deploy.yml` (push to main) and `.github/workflows/ssh-deploy.yml` (manual dispatch)

Workflow uses `webfactory/ssh-agent@v0.8.0` to inject the SSH key, then runs:
```bash
ssh "${USER}@${HOST}" "cd /opt/data/hermes-sync/projects/agent-os && docker compose pull && docker compose up -d"
```

**agent-os repos:** `ChonSong/agent-os` (monorepo), `ChonSong/nanobot` (fork of HKUDS/nanobot), `ChonSong/hermes-agent`
**Images:** `ghcr.io/chonsong/agent-os-dashboard`, `ghcr.io/chonsong/agent-os-nanobot`
**Dashboard port:** 9119

## Known Issues

- `repo-transmute` pytest test discovery broken — `pyproject.toml` configures `tests/` but pytest not discovering. Verify before running `test` task type.
- Cron job `6576b5f87515` updated to run `roadmap_engine.py --phase all` (was `overnight_engine.py`)
- `hermes chat` subagent spawning uses `-t browser` for browser tasks, `-t web` for research

## Running

```bash
# All phases
/opt/hermes/.venv/bin/hermes execute --command "python /opt/data/hermes-sync/scripts/roadmap_engine.py --phase all"

# Single phase
/opt/hermes/.venv/bin/hermes execute --command "python /opt/data/hermes-sync/scripts/roadmap_engine.py --phase 1"
/opt/hermes/.venv/bin/hermes execute --command "python /opt/data/hermes-sync/scripts/roadmap_engine.py --phase 2"
/opt/hermes/.venv/bin/hermes execute --command "python /opt/data/hermes-sync/scripts/roadmap_engine.py --phase 3"
```

**Workspace path:** `/opt/data/hermes-sync/` (NOT `/opt/workspace/hermes-sync/`)

## Running

## References

See `references/implementation-notes.md` for session-specific detail (Phase 1 findings, repo scan results, test coverage gaps discovered).
See `references/quality-gap-analysis.md` for the quality gap analysis and 8-step improvement roadmap.
See `references/self-improvement-pipeline.md` for the self-improvement loop: scoring algorithm, candidate sources, authoring workflow, and skill lifecycle.
