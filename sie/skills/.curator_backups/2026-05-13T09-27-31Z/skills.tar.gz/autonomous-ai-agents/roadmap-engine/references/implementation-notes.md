# Roadmap Engine — Implementation Notes (May 1, 2026)

## Phase 1 Findings

### Repos Scanned
- `repo-transmute` — test coverage gap: 0 tests collected
- `everything-dashboard` — clean, no TODOs/FIXMEs found
- `hermes-agent` — 5 learnings surfaced
- `nanobot` — 1 blocker surfaced (Docker bind mount path non-existent)

### repo-transmute Test Discovery Bug
- `pyproject.toml` configures `tests/` as test path
- `pytest --co` returns 0 collected tests
- Likely needs `__init__.py` in `tests/` or test file naming pattern fix
- **Action required before running `test` task type on this repo**

### nanobot Blocker
- `provider_manager.py` referenced `/workspace` but container uses `/opt/workspace`
- Already patched in current session: proxy bypass + HERMES_HOME-aware key loading
- Confirmed working: rclone Google Drive read/write, OAuth token refresh

## Phase 2 Status (as of May 1)

| Task Type | Status | Notes |
|-----------|--------|-------|
| `test` | ✅ Works | Stub executor runs pytest; needs pre-flight check for repo-transmute |
| `code` | 🔧 Stub | Logs "Would execute code task via delegate_task" — not wired |
| `research` | 🔧 Stub | Logs intent only |
| `browser` | 🔧 Stub | Logs intent only |
| `review` | 🔧 Stub | Logs intent only |

## Phase 3 Status

- `reporters.py` generates narrative report with health score, carry-forward list
- Report output: `nightly-reports/report-YYYY-MM-DD.md`
- Health score formula: `100 * tests_passing + design_quality + user_experience + autonomous_simulation + research_discovery` / 500

## Cron Job

- Job ID: `33ee3807d679`
- Current: `sync-and-push.sh` every 6h
- Needs update to: `roadmap_engine.py --phase all`
