# Roadmap Autonomy Engine — Design Reference

> **Source:** `workspace/plans/roadmap-engine-spec.md` in hermes-sync  
> **Status:** Active — being implemented per phases listed below

## Quick Reference

A **long-horizon autonomous planning and execution system** that:

1. Revises a persistent `roadmap.json` each night (top-down goals + bottom-up discovery)
2. Executes tasks across 5 dimensions: tests_passing, design_quality, user_experience, autonomous_simulation, research_discovery
3. Reports to morning briefing with carry-forward tracking

## Directory Structure

```
hermes-sync/scripts/
├── roadmap_engine.py    # Main entry point (Phase 1+2+3 runner)
├── roadmap.py            # Data model + roadmap CRUD
├── planner.py             # LLM-driven task planning
├── executor.py            # Task execution (test, code, research, browser, review)
├── research.py            # Discovery-driven bottom-up idea generation
└── reporters.py           # Report generation
```

## Roadmap Schema

`workspace/plans/roadmap.json` — single source of truth:

- `goals[]` — top-down objectives (set by Sean or reverse-engineered from priorities)
- `projects[]` — repos with metadata
- `tasks[]` — executable work items with status, priority, effort, skills_required
- `ideas[]` — voted on, promoted to tasks at 3+ votes
- `learnings[]` — findings that persist across sessions
- `blockers[]` — known external dependencies
- `activity_log[]` — per-session history

## Task Types (Executor)

| Type | Executor Method |
|------|----------------|
| `test` | Write/run pytest; LLM generates if 0 collected |
| `code` | TDD: tests first, then implementation |
| `research` | Clone analysis + web search + doc findings |
| `browser` | Spawn `browser-agent` subagent with task prompt |
| `review` | GitHub API diff + linter + LLM review |

## Key Resolved Decisions

- **Browser**: Use `browser-agent` skill (native Hermes browser tools: browser_navigate, browser_click, browser_snapshot, browser_vision). Do NOT install standalone Playwright/Selenium.
- **GitHub token**: `~/.netrc` with PAT — handled natively via urllib (no CLI dependency)
- **Hermes binary**: `/opt/hermes/.venv/bin/hermes`
- **Available toolsets**: `browser`, `cronjob`, `file`, `session_search`, `skills`, `terminal`, `web`
- **xvfb-run**: Available at `/usr/bin/xvfb-run` (for headless GUI tasks)

## Nightly Session Cycle

```
Phase 1 RESEARCH (30-60 min):
  Clone/pull repos → scan TODOs/FIXMEs → GitHub issues → CI failures
  → LLM planner revises roadmap.json → snapshot to roadmap-history/

Phase 2 EXECUTE (until 23:00 Sydney = 14:00 UTC):
  Load top tasks → verify preconditions → execute via appropriate executor
  → record results → update roadmap → commit hermes-sync changes

Phase 3 REPORT (15-30 min):
  Generate narrative report → critical issues to Telegram → rest to morning briefing
  → push roadmap.json + report to git
```

## Productivity Dimensions

| Dimension | Metric |
|-----------|--------|
| Tests Passing | Well-designed tests covering real behavior |
| Design Quality | Readable, maintainable, good architecture |
| User Experience | Products solve user problems; UI/UX simulation |
| Autonomous Simulation | Engine exercises browser, vision, multi-step flows |
| Research & Discovery | Goals, ideas, blockers surfaced from code |

## Implementation Order

```
Phase 1: Core data model + roadmap.json schema + CRUD          ← START HERE
Phase 2: Phase 3 report generator (reads state → writes report)
Phase 3: Phase 1 research module (code scanning, GitHub issues)
Phase 4: Phase 1 LLM planner integration
Phase 5: Phase 2 executor (test, code, research, review task types)
Phase 6: Cron job update + end-to-end test
Phase 7: browser task type (spawns browser-agent subagent)
Phase 8: Vision integration for autonomous simulation
```

## Known Issue from Legacy Engine

`repo-transmute` had 0 tests collected — `pyproject.toml` configures `tests/` but pytest was not discovering. After initial setup, verify test discovery works before running test tasks.

## Extensibility

- New task types: add enum + `execute_TYPE()` + dispatch entry
- New discovery sources: add `scan_SOURCE()` in `research.py`
- New metrics: add field to Task model + update report + update planner scoring
