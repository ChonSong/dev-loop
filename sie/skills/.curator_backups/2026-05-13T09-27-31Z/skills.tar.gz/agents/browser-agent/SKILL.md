---
name: browser-agent
description: Browser Agent — web automation agent. Handles browser-based automation, web scraping, and UI interaction.
version: 1.0.0
author: migrated-from-openclaw
category: agents
metadata:
  openclaw_id: browser-agent
  openclaw_name: "Browser Agent – Web Automation"
  model:
    primary: minimax/MiniMax-M2.7
    fallbacks:
      - minimax/MiniMax-M2.5
      - litellm/minimax-m2.7-highspeed
      - litellm/minimax-m2.7
---

# Browser Agent – Web Automation

Browser Agent automates browser-based tasks including web scraping, form filling, and UI interaction.

## Tools
- browser, read, write, exec, web_search, subagents, sessions_spawn, sessions_list

## Use case
Automating web interactions, scraping dynamic content, testing web UIs, and browser-based workflows.