---
name: ubd-docx-generator
description: Generate filled .docx UbD (Understanding by Design) lesson plan templates using Node.js docx npm package. Used when Alto asks for a filled-in DOCX template rather than markdown.
version: 1.0.0
license: MIT
metadata:
  hermes:
    tags: [education, curriculum, UbD, DOCX, nodejs]
    related_skills: [curriculum-design]
---

# UbD DOCX Generator

## When to Use

Trigger when the user asks to:
- Return a filled-in DOCX template
- Convert an outline to a Word document
- Generate a `.docx` version of lesson plans or unit of work

> **Why not python-docx?** The Hermes container has no `pip` and `python-docx` cannot be installed via standard means. Use the Node.js `docx` npm package instead.

## Setup

```bash
npm config set cache /tmp/npm-cache
npm install --prefix /tmp/node_proj docx
```

## Quick-Start

1. Copy the template script at `templates/ubd_docx_gen.cjs` to your working directory
2. Fill in the `UNIT` constant with topic-specific content (year, stage, topic, outcomes, etc.)
3. Add remaining content sections (assessment, blocks, lessons, justification)
4. Run: `node ubd_docx_gen.cjs`
5. Output: `TEAC_5003_UbD_Filled.docx`

## Required Dependencies

```bash
npm config set cache /tmp/npm-cache
npm install --prefix /tmp/node_proj docx
```

Then `require('/tmp/node_proj/node_modules/docx')` in the script.

## Key API Patterns (docx v1.1.2)

```javascript
const {
  Document, Packer, Paragraph, TextRun, Table, TableRow, TableCell,
  HeadingLevel, WidthType, ShadingType, TableLayoutType, VerticalAlign, PageBreak
} = require('/tmp/node_proj/node_modules/docx');

// Header cell (blue shading)
function hCell(text) {
  return new TableCell({
    children: [new Paragraph({ children: [new TextRun({ text, bold: true })], spacing: { after: 40 } })],
    shading: { fill: "D9E2F3", type: ShadingType.CLEAR, color: "auto" },
    verticalAlign: VerticalAlign.CENTER,
  });
}

function dCell(text) {
  return new TableCell({
    children: [new Paragraph({ children: [new TextRun({ text })], spacing: { after: 40 } })],
    verticalAlign: VerticalAlign.CENTER,
  });
}

function bCell(text) {
  return new TableCell({
    children: [new Paragraph({ children: [new TextRun({ text, bold: true })], spacing: { after: 40 } })],
    verticalAlign: VerticalAlign.CENTER,
  });
}

function row(cells) { return new TableRow({ children: cells }); }

function makeTable(rows) {
  return new Table({
    width: { size: 100, type: WidthType.PERCENTAGE },
    layout: TableLayoutType.FIXED,
    rows,
  });
}

function pb() {
  return new Paragraph({ children: [new PageBreak()], spacing: { before: 0, after: 0 } });
}

// Build document
const doc = new Document({
  sections: [{
    properties: { page: { margin: { top: 1080, bottom: 1080, left: 1080, right: 1080 } } },
    children: [h1("Title"), makeTable([row([hCell("H"), dCell("Data")])]), pb(), /* more content */],
  }],
});

Packer.toBuffer(doc).then(buffer => {
  fs.writeFileSync('/opt/data/cache/documents/Output.docx', buffer);
});
```

## Pitfalls

1. **opts spreading into TableCell** — always destructure `width` out first: `const { width, ...cellOpts } = opts`
2. **`.cjs` vs `.js`** — if `/tmp/package.json` has `"type": "module"`, use `.cjs` extension
3. **`ShadingType.CLEAR` requires `color: "auto"`** — without it, the table rendering throws `TypeError: Cannot read properties of undefined (reading 'slice')`
4. **`npm install` permission errors** — always use `--prefix /tmp/node_proj` to avoid `chown` failures on `/opt/data/home/.npm`

## Relevant Skills

- `curriculum-design` — contains the NESA UbD content structure, syllabus outcomes, glossary, and justification framework needed to fill the template
