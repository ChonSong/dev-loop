---
name: autonomous-cron-pipeline
description: Schedule multi-phase autonomous work as chained cron jobs with dependency markers, staggered timing, and push notifications.
category: autonomous-ai-agents
version: 1.0.0
---

# Autonomous Cron Pipeline

Schedule multi-phase autonomous tasks as a chain of one-time cron jobs. Each phase checks for the previous phase's completion marker before starting, creating a dependency chain that runs unattended.

## When to Use

- Large tasks that would exceed a single session's tool limits
- Work the user wants to "let cook" without staying present
- Phases with real dependencies (Phase 2 needs Phase 1's output)
- Tasks where the user wants progress notifications via Telegram

## Pattern

### Step 1: Write the execution plan

Create a markdown plan with:
- Phase checklist items with concrete acceptance criteria
- Completion markers: `echo "PHASE_N_COMPLETE" > /tmp/<project>-phase-N.done`
- Error markers: `echo "error details" > /tmp/<project>-phase-N.error`
- Working directory, commands, and architectural references

Save as `/opt/data/<project>-planning/AUTONOMOUS-EXECUTION-PLAN.md`

### Step 2: Create chained cron jobs

Create one cron job per phase with:
- **Staggered schedules** — space phases by 6-12 hours depending on expected duration
- **Dependency check** — each phase's prompt starts with:
  ```
  FIRST: Check if Phase N-1 is complete:
  - If /tmp/<project>-phase-(N-1).done exists, proceed.
  - If not, check /tmp/<project>-phase-(N-1).error for details and report the blocker, then exit.
  ```
- **Toolsets** — give each phase only the tools it needs (terminal+file is enough for code work; add browser+web for visual/UI tasks)
- **Workdir** — set to the project directory
- **Deliver** — Sean prefers `discord` (home channel) for cron job notifications. Do NOT use `telegram` unless explicitly asked. Set to `local` for no notifications.

### Step 3: Force-run Phase 1 if the scheduled time already passed

**PITFALL**: `schedule: "once at 2026-05-11 09:35"` will show `next_run_at: null` if the current time is past that moment. The job won't auto-trigger. Fix by running:
```
cronjob action=run job_id=<phase1_id>
```

## Cron Job Parameters

```python
cronjob action=create
    name="Project Phase N: Description"
    schedule="2026-05-12T03:00:00"   # UTC one-time execution
    deliver="discord"                 # Push notification to user (Sean prefers Discord home)
    workdir="/opt/data/project-root"  # Working directory
    enabled_toolsets=["terminal", "file", "web", "browser"]  # Phase-appropriate tools
    prompt="..."                      # Full phase instructions
```

## Prompt Template for Each Phase

```markdown
Execute Phase N of the <project> completion plan.

FIRST: Check if Phase N-1 is complete:
- If /tmp/<project>-phase-(N-1).done exists, proceed.
- If not, check /tmp/<project>-phase-(N-1).error for details and report the blocker, then exit.

**ALWAYS verify git state first.** Run:
  cd <workdir> && git log --oneline -10 && git status --short
If the phase's expected commit is already in git (tracker drifted from reality),
update the tracker to match and stop. Never re-execute an already-done phase.

Read the full plan at /opt/data/<project>-planning/AUTONOMOUS-EXECUTION-PLAN.md

PHASE N TASKS:
1. [specific task with file paths]
2. [specific task with file paths]
...

WORKING DIR: /opt/data/<project-root>

IMPORTANT: Write completion marker when done:
echo "PHASE_N_COMPLETE" > /tmp/<project>-phase-N.done

If any step fails, write error details to /tmp/<project>-phase-N.error
and describe what was completed vs what failed.
```

## Dependency Chain Architecture

```
Phase 1 (runs now)  →  .done marker  →  Phase 2 (6h later)
                                                      ↓
                                               .done marker
                                                      ↓
Phase 4 (30h later) ←  .done marker  ←  Phase 3 (18h later)
```

Each phase is **independent** — if Phase 2 fails, Phase 3 still checks the marker and skips with a clear error report rather than hanging or failing silently.

## Monitoring

- `cronjob action=list` — see all job states and next_run_at times
- `cronjob action=remove job_id=<id>` — cancel a phase
- `cronjob action=pause job_id=<id>` — pause without deleting
- Check `/tmp/<project>-phase-N.done` and `/tmp/<project>-phase-N.error` for current state

## Critical Decision: Direct Execution vs Persistent Phase Engine

**When the user asks to "complete large projects" — ALWAYS use the Persistent Phase Engine with recurring cron jobs.** Never try to rush through multiple phases in a single session. Never use `once at <timestamp>` one-shot jobs for critical work.

### Why Direct Session Execution Fails for Multi-Phase Work

| Problem | What Happens |
|---------|--------------|
| Context compaction | Loses state every ~150K tokens, quality degrades |
| Rushing | Skipping verification steps leads to broken commits |
| Session death | All uncommitted work is lost |
| User skepticism | "im not confident it will be completed with high quality" — a signal to STOP and switch to cron |
| Scheduler misses ticks | One-shot `once at` jobs show `next_run_at: null` and never fire |

### The Decision Rule

- **1-2 phases, well-defined, user present** → Direct execution is fine
- **3+ phases, complex, or user wants to "let it cook"** → Persistent Phase Engine with `every 30m` cron, ALWAYS
- **User questions quality/approach mid-session** → IMMEDIATELY switch to cron jobs. Don't try to "prove" direct execution works.
- **Never use `once at <timestamp>`** for critical work — the scheduler will likely miss the tick.

### If User Questions Approach Mid-Session

1. **Acknowledge** — "You're right, this approach won't scale"
2. **Stop** — Don't commit partial work
3. **Switch** — Set up recurring cron job with PHASE_TRACKER.json
4. **Verify** — Check git log before scheduling to avoid scheduling already-done work
5. **Commit** — Only commit if the current phase is complete and verified

---

## Preferred Pattern: Persistent Phase Engine (NEW — May 2026)

**For large projects (1M+ tokens), the dependency-marker approach above is fragile.** A disk-based state machine is superior. This pattern was discovered after multiple failures with chained cron jobs and subagent timeouts.

### Why Dependency Markers Fail

| Failure Mode | What Happens |
|--------------|--------------|
| Context compaction | Loses state every ~150K tokens |
| Subagent timeouts | 600s limit kills complex tasks |
| Session amnesia | Cron jobs start fresh with zero memory |
| No checkpointing | Interrupted sessions lose uncommitted work |
| Token exhaustion | Single session hits model limits |
| Non-idempotent phases | Can't retry failed work safely |
| `/tmp/` markers don't survive | Session restarts clear temp files |

### The Persistent Phase Engine Architecture

```
/opt/data/project-state/<project>/
├── PHASE_TRACKER.json      ← Machine-readable state (current phase, status, checkpoints)
├── CHECKPOINTS/            ← Human-readable completion records per phase
│   ├── phase-A-complete.md
│   ├── phase-B-complete.md
│   └── ...
├── PROGRESS.md             ← Running progress log
└── NEXT_ACTION.md          ← What the next session should do
```

### PHASE_TRACKER.json Structure

```json
{
  "project": "hermes-web-computer",
  "total_phases": 12,
  "current_phase": 7,
  "status": "in_progress",
  "phases": [
    {"id": "A-B", "name": "CSS foundation", "status": "complete", "commit": "21819ae", "checkpoint": "phase-AB-complete.md"},
    {"id": "C", "name": "Floating panels", "status": "pending", "checkpoint": null}
  ],
  "next_action": "Implement Phase C: Floating panels",
  "next_action_details": "Add glassmorphism styling to Tile, LeftPanel, RightPanel",
  "workdir": "/opt/data/hermes-web-computer",
  "last_updated": "2026-05-12T03:34:00Z"
}
```

### Cron Job Pattern (The Reliable One)

```yaml
name: "phase-engine: <project> completion"
schedule: "every 30m"          # Runs repeatedly until all phases done
repeat: "1/20"                # Max runs (safety limit, format: "N/limit")
deliver: "discord"            # Sean prefers Discord, NOT Telegram
enabled_toolsets: ["terminal", "file"]
prompt: |
  Execute next phase of <project> using the persistent phase engine.

  STATE_DIR: /opt/data/project-state/<project>/
  WORKDIR: /opt/data/<project>/

  INSTRUCTIONS:
  1. Read PHASE_TRACKER.json to find the next pending phase.
  2. **VERIFY GIT BEFORE EXECUTING**: Run `cd <workdir> && git log --oneline -10` and
     `git status --short`. If the pending phase's expected commit is already in git
     (or tracker says "complete" but git shows uncommitted work from a prior session),
     the phase is already done — update the tracker to match git reality and stop.
     This prevents wasted work when a prior session completed the phase but didn't
     update the tracker before dying.
  3. If all phases complete → report success and stop.
  4. If next phase is genuinely pending → execute it completely.
  5. After execution:
     a. Verify build/tests pass
     b. git add + commit + push
     c. Write checkpoint to CHECKPOINTS/phase-{id}-complete.md
     d. Update PHASE_TRACKER.json with completion status AND the commit hash
  6. Report results.

  CRITICAL RULES:
  - Execute ONE phase per run (the first pending one)
  - NEVER skip phases - execute in order
  - ALWAYS verify git state first — tracker may say "pending" when work is already done
  - ALWAYS verify before committing
  - If phase fails, write error to tracker and stop
  - Each phase should be under 50K tokens of work

### Phase Design Principles

1. **Idempotent** — Can be run multiple times safely
2. **Atomic** — Either completes fully or fails cleanly
3. **Verifiable** — Has clear success criteria (build passes, tests pass)
4. **Self-documenting** — Writes checkpoint with decisions and changes
5. **Small** — Under 50K tokens per phase (~15-20 min of work)
6. **Commits independently** — Each phase commits so progress survives timeout

### How It Survives Everything

| Threat | How Phase Engine Handles It |
|--------|----------------------------|
| Context compaction | State is on disk, not in memory |
| Session timeouts | Next session reads tracker and continues |
| Session restarts | Tracker file persists across restarts |
| Cron job failures | Error recorded, stops safely, next run retries |
| Token exhaustion | Work split across many sessions, 50K each |
| Interrupted work | Checkpoints mark safe resume points |
| Docker isolation | Can run each phase in separate container via Docker socket (mounted at `/var/run/docker.sock`) |

### Token Budget Math

```
Per phase: ~50K tokens (work + verification + commit)
State management: ~5K tokens (read/write tracker)
1M token project: ~20 phases × 50K = 1M tokens
Plus overhead: ~20 cron runs × 5K = 100K
Total: ~1.1M tokens, distributed across 20+ sessions
```

---

## Alternative: Single Mega-Job with Phase-by-Phase Commits

**For multi-phase feature work where phases share the same codebase**, a single cron job is often simpler and more resilient than chained jobs:

```
cronjob action=create
    name="project: overnight completion — all remaining features"
    schedule="2026-05-11T23:55:00"    # one-shot
    deliver="discord"                  # or your preferred channel
    enabled_toolsets=["terminal", "file", "browser"]
    prompt="Complete ALL remaining features for <project>. WORKING DIR: <path>.

IMPORTANT: After EACH phase, run build verification. If it passes, git add + commit + push. This way progress is saved even if later phases timeout.

PHASE A: <description, tasks>
PHASE B: <description, tasks>
PHASE C: <description, tasks>
..."
```

**Why this beats chained jobs for feature work:**
- No dependency markers to manage
- One cron job, not N
- Each phase commits independently — if timeout hits at phase 4, phases 1-3 are already on GitHub
- No chain-break risk
- Simpler to set up and monitor

**When to use chained jobs instead:**
- Phases that run on different machines or different codebases
- Phases with long delays between them (days, not hours)
- Phases where output from one must be consumed by the next (data processing pipelines)

## Sandcastle Comparison (May 2026)

**Sandcastle** (github.com/mattpocock/sandcastle, 3K+ stars) is a TypeScript library for orchestrating AI coding agents in isolated Docker containers with git worktrees.

### When to Use What

| Approach | Best For | Tradeoffs |
|----------|----------|-----------|
| **Persistent Phase Engine** | Large projects within Hermes ecosystem | Simple, self-contained, no external deps. No Docker isolation, no parallelism. |
| **Sandcastle** | Multi-agent parallel workflows, CI integration | Better isolation (Docker + worktrees), native parallelism, merge-back safety. Requires TypeScript setup, external agent providers (Claude Code, Codex). |
| **Chained cron jobs** | Independent phases on different codebases | Simple, works anywhere. No state machine, fragile dependency markers. |

### Docker Isolation Within Phase Engine

The Persistent Phase Engine can gain Docker isolation WITHOUT switching to Sandcastle:

```bash
# Each cron job can run builds/tests in isolated containers:
docker run --rm -v /opt/data/project:/workspace -w /workspace node:20-alpine sh -c "npm install && npm run build"
```

This gives container isolation per phase while keeping the simple JSON tracker state machine.

### Why Not Switch to Sandcastle

- Sandcastle expects Claude Code/Codex agents, not Hermes Agent
- Requires TypeScript execution, git worktree setup
- Overhead of integration outweighs benefits for single-agent workflows
- Docker socket is already mounted and working from container — can run isolated builds without Sandcastle

---

## `/goal` Command vs Phase Engine

Hermes has a built-in `/goal` slash command (the "Ralph loop") that auto-continues across turns until a goal is achieved. **It only works within a single session** — context compaction breaks it for large projects.

**Decision rule:**
- Single-session task (< 150K tokens) → `/goal <text>`
- Multi-phase project, "let it cook" → Persistent Phase Engine (this skill)
- User questions quality mid-session → STOP → switch to cron jobs

See `references/goal-vs-phase-engine.md` for full comparison and decision tree.

**CRITICAL: Never use `once at <timestamp>` for critical work.** One-shot scheduled jobs are fundamentally unreliable — the scheduler may miss the tick, resulting in `next_run_at: null` and the job never firing.

**The ONLY reliable pattern:** `every 30m` + PHASE_TRACKER.json state check. Each run reads the tracker, executes the next pending phase, updates the tracker. Even if a tick is missed, the next run picks up where it left off.

```yaml
name: "phase-engine: <project> completion"
schedule: "every 30m"          # NOT "once at <timestamp>"
repeat: "1/20"                # Start with 1/20, safety limit 20 runs
deliver: "discord"
enabled_toolsets: ["terminal", "file"]
prompt: |
  Read /opt/data/project-state/<project>/PHASE_TRACKER.json.
  Find the first phase with status != "complete".
  Execute it, verify, commit, write checkpoint, update tracker.
```

### If You MUST Use One-Shot Jobs

If you use `once at <timestamp>` (e.g., for a specific time window):
1. Force-run immediately with `cronjob action=run job_id=<id>`
2. Verify `next_run_at` is not `null` after creation
3. Don't rely on the scheduler to catch the exact time

## Pitfalls

1. **`cronjob action=run` does NOT execute immediately** — It queues the job for the next scheduler tick (usually 30-60 seconds). You will NOT see output in the current session. The job runs in a separate session and delivers results via the configured channel (discord/telegram). If you need immediate execution with feedback, run the work directly with `delegate_task` or `terminal` instead of using cron.
2. **Read-only mounts in Docker containers** — Some directories (like `/opt/data/hermes-sync`) are mounted read-only from the host. You cannot write files or commit changes from inside the container. Check with `touch /path/test && rm /path/test` before attempting writes. Workaround: write to a writable directory, then push from the host.
3. **Git divergent branches** — When local and remote have diverged with no common ancestor, `git pull --rebase` fails with "unrelated histories". Use `git push --force-with-lease` to overwrite remote (requires user approval for force push).
4. **`next_run_at: null`** — If the scheduled time is in the past, the job won't fire. Fix by updating the schedule to a future time: `cronjob action=update job_id=<id> schedule="2026-05-12T00:41:00"`. Then either wait or use `cronjob action=run`.
5. **Too-close scheduling** — Phases that run before the previous one finishes will find no `.done` marker and skip. Space phases by at least the expected duration + 2 hours buffer.
6. **Missing completion marker** — The prompt must explicitly instruct the phase to write the `.done` file. Without it, the chain breaks.
7. **Error handling** — Phases should `exit 0` even on failure (after writing the `.error` file). A non-zero exit blocks the cron system, not just the next phase.
8. **Toolset scoping** — Give each phase only the tools it needs. Phase 4 (polish) doesn't need browser access; Phase 2 (new UI) does.
9. **Session context loss** — Each cron job runs in a fresh session. The prompt must include all context — don't assume prior session knowledge. Include file paths, architectural references, and decision rationales.
10. **File path collisions** — Use unique marker file paths per project (e.g., `/tmp/<project>-phase-N.done`, not just `/tmp/phase-N.done`) to avoid cross-project confusion.
11. **User questions quality/approach mid-session** — When the user says "im not confident it will be completed with high quality" or similar skepticism, STOP direct execution immediately. Switch to chained cron jobs. Don't try to prove direct execution works — the user is right. Each phase gets a fresh context window with cron, quality stays high, and work continues even if sessions die.
12. **Docker socket works from container** — `/var/run/docker.sock` is mounted and functional. You CAN run Docker commands from inside the container. This enables isolated builds/tests per phase without needing Docker-in-Docker.
13. **Container filesystem is shared** — All cron jobs run in the same container filesystem. No automatic isolation between phases. If you need isolation, use Docker containers for builds/tests (pitfall 12).
14. **Don't declare features don't exist without checking source** — The `hermes-agent` skill docs claimed `/goal` doesn't exist, but it's implemented in `/opt/hermes/hermes_cli/goals.py`. Always check the actual source code (grep `/opt/hermes/hermes_cli/commands.py` for `CommandDef`) before declaring a feature doesn't exist. Skill docs can be outdated; source code is authoritative.
15. **Always verify git state before scheduling** — Before creating cron jobs for phases, check `git log --oneline` and `git status` to confirm what's already committed. Scheduling cron jobs for already-done work wastes token budget and erodes user trust. Run: `cd <project> && git log --oneline -10 && git status` before scheduling any cron jobs.
16. **User trust is fragile — don't claim work is pending when it's done** — If the user says "im losing trust check if work is actually being done", STOP. Verify the actual state (git log, file contents, test results) and report truthfully. Never schedule cron jobs for work that's already committed. Never claim a phase is "pending" if it's already in git. The PHASE_TRACKER.json can drift from reality — always verify against the source of truth (git) before reporting status.
17. **PHASE_TRACKER.json can drift from reality** — The tracker file is only as accurate as the last session that updated it. Always cross-reference with `git log --oneline` to verify what's actually committed. If tracker says "pending" but commit exists in git, the phase is done. Update the tracker to match reality.
18. **Web search IS enabled by default** — The `web_search` tool is in `_HERMES_CORE_TOOLS` in `toolsets.py`. Don't assume it's disabled — test it with a simple query. API keys for Brave/EXA are in `.env`.
19. **ALWAYS set `model` and `provider` explicitly on every cron job creation** — If you omit these or set `model: null`, the scheduler rejects the job with `400 - Model not exist`. Every cron job created without an explicit model silently fails at runtime. This is the single most common cause of cron failures.

**The correct values for MiniMax M2.7:**

| Field | Value | Notes |
|-------|-------|-------|
| `model` | `"minimax-m2.7"` | Short form, NOT `"minimax/minimax-m2.7"` |
| `provider` | `"minimax-portal"` | Points to `https://api.minimax.io/anthropic` |

**NEVER use `provider: "minimax"`** — the `minimax` provider (localhost:4001/v1) is a local proxy that's offline. Use `minimax-portal` which hits the real MiniMax API directly and bypasses the AliYun token-plan quota.

**Why `minimax-portal` instead of `minimax`:**
- `minimax`: `http://localhost:4001/v1` — local proxy, currently offline/error
- `minimax-portal`: `https://api.minimax.io/anthropic` — real MiniMax API, working

**How to discover provider names:** Look in `/opt/data/config.yaml` under `custom_providers[].name`. The provider name in the cron `model` object must match one of these exactly.

**Always verify after creation** — check the returned JSON shows `"model": "minimax-m2.7"` not `"model": null`. If it shows `null`, the job will fail at runtime.

**The `repeat` field format is `N/limit`** — e.g., `"3/20"` means 3 of 20 runs used. Use `"1/20"` for initial runs with a safety limit.
20. **Always commit uncommitted work before setting up a phase engine** — The phase engine's cron job starts from git HEAD. If there are uncommitted changes (modified files, new files), the cron job will pick them up but they'll be in an inconsistent state relative to the PHASE_TRACKER. Before creating a new phase engine cron, always: `cd /opt/data/<project> && git status --short && git add + git commit` to ensure a clean starting point.

## References

See `references/hermes-web-computer-plan.md` for a concrete example: the full 4-phase plan to complete hermes-web-computer v1.0 (Editor save, Agent chat, Voice UI, Browser tile, Dashboard migration, Polish).
See `references/phase-engine.md` for the Persistent Phase Engine architecture, cron job templates, checkpoint templates, and token budget math for 1M+ token projects.
See `references/sandcastle-comparison.md` for detailed comparison with Sandcastle (github.com/mattpocock/sandcastle) — when to use each approach, Docker socket discovery, and integration tradeoffs.
See `references/goal-vs-phase-engine.md` for full comparison and decision tree between `/goal` command and Persistent Phase Engine.
See `references/cron-scheduler-behavior.md` for documented scheduler tick behavior, one-shot job failures, and the reliable recurring pattern.
