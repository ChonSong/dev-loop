---
name: nanobot-to-hermes-migration
description: "Migrate a custom nanobot orchestration repo to stock Hermes Agent. Three-phase integration: socket realignment, skill salvage + MCP conversion, Hermes state management. Trigger when retiring nanobot or integrating Hermes as a replacement brain."
tags: ["hermes", "nanobot", "migration", "integration", "mcp", "websocket"]
related_skills: ["infrastructure-as-code", "native-mcp", "subagent-driven-development", "writing-plans"]
---

# nanobot → Hermes Agent Migration

## When to Use

Triggered when:
- Decommissioning `packages/nanobot/` in favor of stock Hermes
- Integrating Hermes as the brain for an existing React frontend
- Converting custom nanobot skills to MCP servers consumable by Hermes

## Phase 1: Frontend Socket Realignment

**Goal:** Point the React frontend's WebSocket listeners from the old nanobot event bus to Hermes's native WebSocket/API endpoints.

### Backend: `backend/src/routes/agent.ts`

Replace nanobot sidecar proxy with Hermes API server proxy:

- Port: `8001` (nanobot) → `8642` (Hermes)
- Retain `POST /api/agent/forward` as the event bridge
- Retain `agentEvents` EventEmitter for Socket.IO forwarding
- Hermes health check: `GET /health` → check `127.0.0.1:8642`
- Hermes run endpoint: proxy to `POST /v1/chat/completions` at `127.0.0.1:8642`
- Keep `HERMES_API_KEY` auth header reading from env

### Backend: `backend/src/index.ts`

Remove nanobot EventEmitter relay wiring — specifically any `agentEvents.on('agent:start'/'agent:output'/'agent:end', ...)` chains that fed Socket.IO. Keep `__io` global and Socket.IO server setup.

### Frontend: `frontend/src/lib/socket.ts`

Event name remapping (nanobot → Hermes):
- `agent:start` → `start`
- `agent:output` → `output`
- `agent:end` → `end`

Export Hermes event types:
```typescript
export interface HermesStartEvent { session_id: string; model: string }
export interface HermesOutputEvent { content: string; tool_calls?: HermesToolCall[]; tool_results?: ToolResult[]; session_id?: string }
export interface HermesToolCall { id: string; name: string; input: Record<string, any> }
export type HermesEndEvent = { session_id: string; usage?: any; done: boolean }
```

### Frontend: `frontend/src/components/Chat/Chat.tsx`

Hermes streaming payload shape:
- `output` events with `data?.type === 'start'` guard should be removed — Hermes `start` events don't have a `type` field
- Use `lastAssistantIdRef` to track which message element receives streamed tokens
- Tool calls appear in `output.tool_calls[]` and must be merged progressively into `tools_used`
- Session ID comes from `start.session_id` — store it for the `/api/agent/forward` payload

### Verify

```bash
# Start Hermes gateway
hermes gateway restart

# Start backend
cd backend && npm run dev

# Start frontend
cd frontend && npm run dev

# Send a test message — should flow:
# React → POST /api/agent/run → Hermes :8642 → /v1/chat/completions
# Hermes → POST /api/agent/forward → backend → Socket.IO → React
```

## Phase 2: Skill Salvage & MCP Conversion

### Audit nanobot Skills

Skills live in `packages/nanobot/nanobot/skills/`. For each skill, check:

| Signal | Action |
|---|---|
| Hermes already has equivalent (built-in tool or skill) | Skip — use Hermes native |
| nanobot-specific capability (unique workflow, custom metadata) | Wrap as MCP server |
| Deprecated/obsolete | Drop |

### Custom Skills Not in Stock Hermes

- **`my`** — Self-awareness/metadata system (`BLOCKED`, `READ_ONLY` flags on tools). Hermes has no equivalent. Wrap as MCP if needed.
- **`clawhub`** — NousDeploy/Clawhub hosting platform integration. Not portable; superseded by Hermes's own `hermes skills` CLI.
- **`skill-creator`** — nanobot-specific skill authoring workflow. Superseded by Hermes's `skill_manage` tool.

### MCP Server Template

For custom capabilities, create a standalone MCP server at `packages/mcp-servers/<name>/`:

```
packages/mcp-servers/<name>/
  SKILL.md           — skill documentation (trigger conditions, tool list, setup)
  server.py          — MCP server implementation (streamable HTTP or stdio)
  requirements.txt   — Python dependencies
```

Server must implement:
- `GET /` → `{"name": "...", "version": "1.0.0", "tools": [...]}`
- `POST /` with `{"method": "tools/list"}` → `{"tools": [...]}`
- `POST /` with `{"method": "tools/call", "name": "...", "arguments": {...}}` → `{"content": [{"type": "text", "text": "..."}]}`

Register with Hermes via native-mcp skill.

### Cloudflare Zero Trust (Reference Implementation)

Location: `/opt/data/agent-os/packages/mcp-servers/cloudflare-zero-trust/`

- 11 tools: tunnel CRUD, DNS routing, Access policy/app CRUD
- Wraps Cloudflare API v4 directly
- Hermes registration via `hermes config add mcp-server`

### Cloudflare MCP Reference

`references/cloudflare-mcp.md` — Cloudflare Zero Trust MCP server: tool inventory, env vars, registration command, Cloudflare API v4 base URL pattern, and token-auth header format.

> **Overlap note:** Cloudflare tunnel setup and `cloudflared` CLI patterns are covered more deeply in the **`infrastructure-as-code`** skill. That skill also has the canonical Terraform + Cloudflare workflow for production tunnel routing.

## Phase 3: Dev/Prod State Management

Hermes stores state in a SQLite database (default: `~/.hermes/hermes.db`). For dev/prod separation:

### Workflow: `hermes-state-migrate.sh`

Located at: `/opt/data/everything-dashboard/scripts/hermes-state-migrate.sh`

```bash
# List backups
./scripts/hermes-state-migrate.sh list

# Inspect live DB schema
./scripts/hermes-state-migrate.sh inspect

# Backup production state
./scripts/hermes-state-migrate.sh backup --output /tmp/prod-backup.db.gz

# Restore to local dev
./scripts/hermes-state-migrate.sh restore /tmp/prod-backup.db.gz
```

**Key constraint:** Always use `SQLite VACUUM INTO` for backups — safe on live databases. Never copy the raw `.db` file while Hermes is running.

**Pre-restore safety:** Script automatically snapshots the current DB before restoring.

## Key Architecture Decision: Option A (Reverse-Proxy + Event Bridge)

Do NOT have the frontend connect directly to Hermes's Socket.IO. Instead:

```
React → backend (Socket.IO) → Hermes API (HTTP) → Hermes events → backend /api/agent/forward → Socket.IO → React
```

This preserves the existing Express backend architecture, maintains auth at one layer, and avoids CORS/websocket complexity.

Hermes forwards events via `API_SERVER_FORWARD_URL=http://localhost:3001/api/agent/forward`.

## Pitfalls

- **Nanobot event names** (`agent:start`, `agent:output`, `agent:end`) must be remapped at the frontend socket layer — Hermes uses `start`, `output`, `end`
- **Hermes `start` events** don't have a `data?.type === 'start'` guard — unlike the old nanobot bus, Hermes sends `start` as the event name directly
- **MCP server registration** — use `hermes config add mcp-server` via the native-mcp skill, not manual JSON config edits
- **Live DB copies** — never `cp` a `.db` file that Hermes has open; use `VACUUM INTO`
- **Skill salvage** — don't waste time rewriting skills Hermes already has; audit first, then only wrap the gaps
- **`write_file` ghost-writing** — for Python files with `b''` bytes literals or shell scripts with `$(...)` command substitution, `write_file` may report success but not persist the file. Workaround: use `execute_code` with Python `open(...).write()` directly. Verify with `ls -la` after write for critical files.
- **`write_file` for Go/shell files**: Python bytes (`b'...'`) and shell variable expansion (`$(...)`) are also problematic. For Go files or shell scripts, use `python3 << 'PYEOF'` heredoc via SSH instead.
- **Cloudflare tunnel token vault redaction** — `CLOUDFLARED_TUNNEL_TOKEN=***` in `.env` means the value is managed by a secrets vault and is NOT readable at runtime. The actual token must be provided directly.
  - **Resolution:** Use the Cloudflare API (`POST /accounts/{id}/tunnels`) to create the tunnel and retrieve a credentials file. See `infrastructure-as-code` skill, `references/cloudflared-tunnel-setup.md` for the full working pattern.
  - **Token format:** `cfat_` (Access token) → API-only, cannot run tunnel. `cfut_` (Unified Tunnel token) → can run tunnel directly. If only `cfat_` is available, API tunnel creation returns a credentials file that bypasses the need for `tunnel run --token`.
- **Docker `docker inspect` password masking** — Docker redacts password substrings in URLs in command output (showing `***`). This is cosmetic only. When verifying passwords in docker-compose.yml on the host, use Python (`import re; re.search(r'postgresql://user:([^@]+)@', c).group(1)`) — not grep, which can misinterpret `***` as a glob pattern.
- **Filesystem is persistent** — `/opt/data` is ext4 on a dedicated partition. If a `write_file` call reports success but `ls -la` shows the file missing, the issue is the tool, not the filesystem. Retry with the `execute_code` workaround.
