#!/usr/bin/env bash
# hermes-state-migrate.sh — Hermes Agent DB state freeze/export/restore
# Part of nanobot-to-hermes-migration skill (Phase 3)
#
# Usage:
#   hermes-state-migrate.sh list                         # list backups
#   hermes-state-migrate.sh inspect [file]               # inspect DB schema
#   hermes-state-migrate.sh backup [--output <path>]     # backup hermes.db
#   hermes-state-migrate.sh restore <backup-file>        # restore from backup
#   hermes-state-migrate.sh diff <a> <b>                 # compare two backups

set -euo pipefail

HERMES_HOME="${HERMES_HOME:-$HOME/.hermes}"
SRC_DB="${HERMES_HOME}/hermes.db"
BACKUP_DIR="${BACKUP_DIR:-${HERMES_HOME}/backups}"
KEEP="${KEEP:-10}"
SKIP_CONFIRM="${SKIP_CONFIRM:-}"

# ── helpers ──────────────────────────────────────────────────────────────────

stamp() { date +%Y%m%d_%H%M%S; }

die() { echo "ERROR: $*" >&2; exit 1; }

need() { command -v "$1" > /dev/null || die "Required: $1"; }

require_db() {
  [[ -f "$SRC_DB" ]] || die "No hermes.db at $SRC_DB"
}

ensure_backup_dir() {
  mkdir -p "$BACKUP_DIR"
}

# ── commands ─────────────────────────────────────────────────────────────────

cmd_list() {
  echo "=== Hermes State Backups (newest first) ==="
  if [[ -d "$BACKUP_DIR" ]]; then
    ls -lt "$BACKUP_DIR"/hermes_*.db.gz 2>/dev/null | awk '{print $5, $6, $7, $8}' || echo "  (no backups found)"
  else
    echo "  (no backups found)"
  fi
}

cmd_inspect() {
  local target="${1:-$SRC_DB}"
  require_db
  need sqlite3

  if [[ "$target" == *.gz ]]; then
    echo "=== Inspecting (decompressing in memory) ==="
    sqlite3 -header -column "$(zcat "$target")" "SELECT name, type FROM sqlite_master WHERE type IN ('table','view','index') ORDER BY type, name;"
    echo ""
    echo "--- hermes_state sample (first 5 rows) ---"
    sqlite3 -header -column "$(zcat "$target")" "SELECT * FROM hermes_state ORDER BY rowid LIMIT 5 2>/dev/null || echo '(table hermes_state not found)'"
  else
    echo "=== Hermes DB: $target ==="
    sqlite3 -header -column "$target" "SELECT name, type FROM sqlite_master WHERE type IN ('table','view','index') ORDER BY type, name;"
    echo ""
    echo "--- FTS5 tables ---"
    sqlite3 "$target" "SELECT name FROM sqlite_master WHERE name LIKE '%fts%';"
    echo ""
    echo "--- hermes_state row count ---"
    sqlite3 "$target" "SELECT COUNT(*) AS 'hermes_state rows' FROM hermes_state 2>/dev/null || echo 'table not found'"
    echo ""
    echo "--- hermes_sessions row count ---"
    sqlite3 "$target" "SELECT COUNT(*) AS 'hermes_sessions rows' FROM hermes_sessions 2>/dev/null || echo 'table not found'"
    echo ""
    echo "--- Sample hermes_state (first 5 rows) ---"
    sqlite3 -header -column "$target" "SELECT * FROM hermes_state ORDER BY rowid LIMIT 5 2>/dev/null || echo '(table not found)'"
  fi
}

cmd_diff() {
  need sqlite3
  local a="${1:-}"; local b="${2:-}"
  [[ -n "$a" && -n "$b" ]] || die "Usage: diff <file-a> <file-b>"

  echo "=== Comparing: $a vs $b ==="

  for f in "$a" "$b"; do
    if [[ ! -f "$f" ]]; then
      echo "WARNING: $f not found, skipping"
      continue
    fi
    local db_args
    [[ "$f" == *.gz ]] && db_args="SELECT COUNT(*) FROM pragma_database_list;" || db_args="SELECT COUNT(*) FROM pragma_database_list;"
    echo "-- $f --"
    sqlite3 "$f" "SELECT name, type FROM sqlite_master WHERE type IN ('table','view') ORDER BY name;" 2>/dev/null
    echo "  Total tables: $(sqlite3 "$f" "SELECT COUNT(*) FROM sqlite_master WHERE type='table';" 2>/dev/null)"
  done
}

cmd_backup() {
  local output="${1:-}"
  require_db
  need sqlite3
  ensure_backup_dir

  if [[ -z "$output" ]]; then
    output="${BACKUP_DIR}/hermes_$(stamp).db.gz"
  fi

  echo "=== Backing up $SRC_DB → $output ==="
  echo "  Using VACUUM INTO (safe on live DB — no lock contention)"

  # Safe snapshot of potentially-live DB
  sqlite3 "$SRC_DB" "PRAGMA integrity_check;" \
    && sqlite3 "$SRC_DB" \
    ". Vacuum INTO '${output}'" 2>/dev/null \
    || sqlite3 "$SRC_DB" ".backup '${output}.tmp' && gzip -c '${output}.tmp' > '${output}' && rm -f '${output}.tmp'" 2>/dev/null \
    || { echo "  Falling back to gzip copy..."; cat "$SRC_DB" | gzip -c > "$output"; }

  # Prune old backups
  local count
  count=$(ls -1 "$BACKUP_DIR"/hermes_*.db.gz 2>/dev/null | wc -l)
  if (( count > KEEP )); then
    echo "  Pruning $(( count - KEEP )) old backup(s)..."
    ls -1t "$BACKUP_DIR"/hermes_*.db.gz | tail -n $(( count - KEEP )) | xargs rm -f
  fi

  echo "  Done: $output ($(du -sh "$output" | cut -f1))"
}

cmd_restore() {
  local backup="${1:-}"
  [[ -n "$backup" ]] || die "Usage: restore <backup-file>"
  [[ -f "$backup" ]] || die "Backup not found: $backup"
  need sqlite3

  # Pre-restore snapshot of current state
  if [[ -f "$SRC_DB" ]]; then
    local pre_snap="${BACKUP_DIR}/pre_restore_$(stamp).db.gz"
    echo "=== Pre-restore snapshot: $pre_snap ==="
    cmd_backup "$pre_snap"
  fi

  if [[ "$SKIP_CONFIRM" != "1" ]]; then
    echo ""
    echo "!!! This will replace your live hermes.db with: $backup"
    echo "!!! A pre-restore snapshot was just created above."
    read -rp "Proceed? (yes/no) " confirm
    [[ "$confirm" == "yes" ]] || { echo "Aborted."; exit 0; }
  fi

  echo "=== Restoring: $backup → $SRC_DB ==="

  if [[ "$backup" == *.gz ]]; then
    zcat "$backup" > "${SRC_DB}.incoming"
  else
    cp "$backup" "${SRC_DB}.incoming"
  fi

  # Pause Hermes briefly
  if command -v hermes > /dev/null 2>&1; then
    echo "  Stopping Hermes gateway..."
    hermes gateway stop 2>/dev/null || true
    sleep 1
  fi

  mv "${SRC_DB}.incoming" "$SRC_DB"

  if command -v hermes > /dev/null 2>&1; then
    echo "  Restarting Hermes gateway..."
    hermes gateway start 2>/dev/null || true
  fi

  sqlite3 "$SRC_DB" "PRAGMA integrity_check;" && echo "  Integrity check: OK" || die "  Integrity check FAILED"

  echo "=== Restore complete: $SRC_DB ==="
}

# ── main ─────────────────────────────────────────────────────────────────────

CMD="${1:-}"
case "$CMD" in
  list)       cmd_list ;;
  inspect)    cmd_inspect "${2:-}" ;;
  backup)     cmd_backup "${2:-}" ;;
  restore)    cmd_restore "${2:-}" ;;
  diff)       cmd_diff "${2:-}" "${3:-}" ;;
  help|--help) echo "Usage: $0 {list|inspect|backup|restore|diff} [args]";;
  *)          echo "Usage: $0 {list|inspect|backup|restore|diff} [args]";;
esac
