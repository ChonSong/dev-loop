# Cloudflare Zero Trust MCP Server — Reference

**Location:** `/opt/data/agent-os/packages/mcp-servers/cloudflare-zero-trust/`

## Tool Inventory (11 tools)

### Tunnel Management
| Tool | Description |
|---|---|
| `list_tunnels` | List all Cloudflare Tunnels (GET `/tunnels`) |
| `create_tunnel` | Create a named tunnel (POST `/tunnels`) |
| `delete_tunnel` | Delete tunnel by UUID (DELETE `/tunnels/{uuid}`) |
| `get_tunnel` | Get tunnel details + connectors (GET `/tunnels/{uuid}`) |

### DNS Routing
| Tool | Description |
|---|---|
| `create_dns_record` | Create CNAME or other DNS record (POST `/zones/{id}/dns_records`) |
| `delete_dns_record` | Delete DNS record (DELETE `/zones/{id}/dns_records/{record_id}`) |

### Access Policies
| Tool | Description |
|---|---|
| `list_access_policies` | List Zero Trust Access policies (GET `/accounts/{id}/access/policies`) |
| `create_access_policy` | Create an Access policy (POST `/accounts/{id}/access/policies`) |
| `update_access_policy` | Update policy by ID (PUT `/accounts/{id}/access/policies/{policy_id}`) |
| `delete_access_policy` | Delete policy (DELETE `/accounts/{id}/access/policies/{policy_id}`) |

### Access Applications
| Tool | Description |
|---|---|
| `list_access_apps` | List Access applications (GET `/accounts/{id}/access/apps`) |
| `create_access_app` | Create an Access application (POST `/accounts/{id}/access/apps`) |
| `delete_access_app` | Delete Access application (DELETE `/accounts/{id}/access/apps/{app_id}`) |

## Environment Variables

```bash
CLOUDFLARE_API_TOKEN=   # Cloudflare API token (not the tunnel token)
CLOUDFLARE_ACCOUNT_ID=  # Found in the Cloudflare Zero Trust dashboard URL
```

**Note:** The `CLOUDFLARED_TUNNEL_TOKEN` (used by `cloudflared` CLI) is NOT the same as `CLOUDFLARE_API_TOKEN`. The MCP server uses the API token for the API v4 interface.

## Hermes Registration

```bash
hermes config add mcp-server cloudflare-zero-trust python /opt/data/agent-os/packages/mcp-servers/cloudflare-zero-trust/server.py
```

Or via config.yaml (stdin transport):
```yaml
mcpServers:
  cloudflare-zero-trust:
    command: python
    args: [/opt/data/agent-os/packages/mcp-servers/cloudflare-zero-trust/server.py]
    env:
      CLOUDFLARE_API_TOKEN: ${CLOUDFLARE_API_TOKEN}
      CLOUDFLARE_ACCOUNT_ID: ${CLOUDFLARE_ACCOUNT_ID}
```

## Cloudflare API v4 Patterns

**Base URL:** `https://api.cloudflare.com/client/v4`

**Auth header:** `Authorization: Bearer $CLOUDFLARE_API_TOKEN`

**Account ID extraction:** From dashboard URL `https://one.dash.cloudflare.com/{account_id}/...` or `cloudflared tunnel list` output.

## Cloudflared Tunnel Serve (for exposing services)

Once you have a tunnel UUID, expose a local service:
```bash
cloudflared tunnel run --url tcp://localhost:8642 $TUNNEL_UUID
```

Or use the tunnel token (for quick ephemeral tunnels):
```bash
cloudflared tunnel --token="$CLOUDFLARED_TUNNEL_TOKEN" run
```

**Note:** `CLOUDFLARED_TUNNEL_TOKEN` is managed by a secrets vault and cannot be read from `.env` at runtime. It must be provided directly.
