# cloudflared Tunnel Setup Reference

## Session outcome (May 7, 2026)

Successfully served `https://os.codeovertcp.com` via Cloudflare Tunnel → Hermes Agent API (port 8642).

**Final infrastructure:**
- Tunnel: `agent-os-final` (UUID: `a74d07d2-0c95-4b25-81c9-68345cca97f3`)
- DNS: CNAME `os.codeovertcp.com` → `a74d07d2-0c95-4b25-81c9-68345cca97f3.cfargotunnel.com` (Cloudflare proxied)
- Config: `/opt/data/cloudflared/config.yml` + `/opt/data/cloudflared/credentials.json`
- cloudflared binary: `/tmp/cloudflared` (v2026.3.0)

**Known issue:** POST to `/v1/chat/completions` via the tunnel returns `build_anthropic_kwargs() got an unexpected keyword argument 'drop_context_1m_beta'` — minimax provider incompatibility, not tunnel-related.

## Config file contents

**`/opt/data/cloudflared/config.yml`:**
```yaml
tunnel: a74d07d2-0c95-4b25-81c9-68345cca97f3
credentials-file: /opt/data/cloudflared/credentials.json

ingress:
  - hostname: os.codeovertcp.com
    service: http://localhost:8642
  - hostname: '*.os.codeovertcp.com'
    service: http://localhost:8642
  - service: http_status:404
```

**`/opt/data/cloudflared/credentials.json`** (from API response `result.credentials_file`):
```json
{
  "AccountTag": "fd4058c7aa1da2cb3ec2f2c9f028c022",
  "TunnelID": "a74d07d2-0c95-4b25-81c9-68345cca97f3",
  "TunnelName": "agent-os-final",
  "TunnelSecret": "..."
}
```

## Tunnel run command

```bash
/tmp/cloudflared tunnel --config /opt/data/cloudflared/config.yml run
```

## Key troubleshooting

| Error | Cause | Fix |
|---|---|---|
| `Provided Tunnel token is not valid` | `cfat_` token used with `--token` flag | Use credentials file + config approach |
| `cloudflared tunnel run requires the ID or name of the tunnel` | Missing `tunnel:` field in config.yml | Add `tunnel: <uuid>` to config.yml |
| `Cannot determine default origin certificate path` | Missing credentials file | Set `credentials-file:` in config or `TUNNEL_ORIGIN_CERT` env |
| `curl` write error 23 | Redirect to `/usr/local/bin` without sudo | Write to `/tmp/` first, then `cp` |

## Cloudflare API base

```
https://api.cloudflare.com/client/v4/
```

Common endpoints:
- `GET /accounts/{account_id}/tunnels` — list tunnels
- `POST /accounts/{account_id}/tunnels` — create tunnel (returns credentials_file)
- `DELETE /accounts/{account_id}/tunnels/{tunnel_id}` — delete tunnel
- `POST /zones/{zone_id}/dns_records` — create DNS record
- `GET /zones?name=codeovertcp.com` — find zone ID

Account ID: `fd4058c7aa1da2cb3ec2f2c9f028c022` (from dashboard URL)
Zone ID for codeovertcp.com: `a0dc1c2d5a810fabb43cb596a7e4b322`
