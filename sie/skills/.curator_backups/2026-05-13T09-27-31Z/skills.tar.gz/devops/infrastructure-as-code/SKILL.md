---
name: infrastructure-as-code
description: Terraform workflows for Cloudflare, AWS, and server provisioning. Covers terraform init/plan/apply, Cloudflare tunnel + Access policy, state management, and GitOps patterns for infrastructure as code.
tags: ["terraform", "cloudflare", "iac", "infrastructure", "dns", "vpn", "tunnel"]
---

# Infrastructure as Code

## Host Environment

The host (hpprobook) does NOT have Terraform installed. For Terraform operations, use Python/scripting approach OR install Terraform to user directory.

### Install Terraform (no sudo needed)

```bash
ssh -o StrictHostKeyChecking=no sean@localhost "mkdir -p ~/.local/bin && curl -fsSL https://releases.hashicorp.com/terraform/1.6.0/terraform_1.6.0_linux_amd64.zip -o /tmp/terraform.zip && unzip -o /tmp/terraform.zip -d ~/.local/bin && chmod +x ~/.local/bin/terraform && ~/.local/bin/terraform version"
```

## Cloudflare Zero Trust MCP Server (alternative to cloudflared CLI)

For programmatic tunnel and Access policy management, use the Cloudflare Zero Trust MCP server instead of cloudflared CLI. It wraps Cloudflare API v4 directly and supports Access policies, service tokens, and tunnel CRUD.

**Location (verified on disk):**
```
/opt/data/agent-os/packages/mcp-servers/cloudflare-zero-trust/
  SKILL.md          — skill documentation
  server.py         — MCP server (11 tools)
  requirements.txt  — httpx, uvicorn, asgiref
```

**Capabilities:**
- Tunnel CRUD (`tunnel_create`, `tunnel_delete`, `tunnel_list`, `tunnel_inspect`)
- DNS routing (`tunnel_route_dns`, `tunnel_delete_dns`)
- Access policy CRUD (`access_policy_list`, `access_policy_create`, `access_policy_delete`)
- Access app registration (`access_app_create`, `access_app_delete`)

**Setup:** Requires `CLOUDFLARE_API_TOKEN` + `CLOUDFLARE_ACCOUNT_ID` env vars. Token needs `Account: Tunnels: Edit`, `Account: Access: Policies: Edit`, `Account: Access: Service Tokens: Edit`.

**Running the server:**
```bash
cd /opt/data/agent-os/packages/mcp-servers/cloudflare-zero-trust
pip install -r requirements.txt
CLOUDFLARE_API_TOKEN=... CLOUDFLARE_ACCOUNT_ID=... python server.py --port 9000
```

**Adding to Hermes (via native-mcp skill):**
```bash
hermes config add mcp-server cloudflare-zero-trust \
  --type stdio \
  --command python \
  --args server.py \
  --cwd /opt/data/agent-os/packages/mcp-servers/cloudflare-zero-trust \
  --env CLOUDFLARE_API_TOKEN \
  --env CLOUDFLARE_ACCOUNT_ID
```

**Key advantage over cloudflared CLI:** Access policy management (identity-based access rules, service tokens, device posture) is only available via API — cloudflared CLI cannot manage Access policies. Use the MCP server for full zero-trust config.

## Cloudflare Tunnel Setup (cloudflared binary)

cloudflared may not be in PATH. Verify before use:
```bash
which cloudflared  # empty if not installed
/tmp/cloudflared --version  # ad-hoc install location
```

### Tunnel creation via Cloudflare API (recommended)

Do NOT rely on `cloudflared tunnel create` interactively. Use the Cloudflare API:

```bash
# 1. Create tunnel
TUNNEL_RESP=$(curl -s -X POST "https://api.cloudflare.com/client/v4/accounts/$ACCOUNT_ID/tunnels" \
  -H "Authorization: Bearer $CLOUDFLARE_API_TOKEN" \
  -H "Content-Type: application/json" \
  -d "{\"name\": \"$TUNNEL_NAME\", \"tunnel_type\": \"cfd_tunnel\"}")

# 2. Parse response
TUNNEL_ID=$(echo "$TUNNEL_RESP" | python3 -c "import json,sys; print(json.load(sys.stdin)['result']['id'])")
TUNNEL_TOKEN=$(echo "$TUNNEL_RESP" | python3 -c "import json,sys; print(json.load(sys.stdin)['result'].get('token','N/A'))")
echo "TunnelID: $TUNNEL_ID"

# 3. Save credentials file (embedded in API response)
echo "$TUNNEL_RESP" | python3 -c "import json,sys; json.dump(json.load(sys.stdin)['result']['credentials_file'], open('/opt/data/cloudflared/credentials.json','w'))"

# 4. Route DNS
curl -s -X POST "https://api.cloudflare.com/client/v4/zones/$ZONE_ID/dns_records" \
  -H "Authorization: Bearer $CLOUDFLARE_API_TOKEN" \
  -H "Content-Type: application/json" \
  -d "{\"type\":\"CNAME\",\"name\":\"subdomain\",\"content\":\"${TUNNEL_ID}.cfargotunnel.com\",\"proxied\":true}"

# 5. Run tunnel
cloudflared tunnel --config /opt/data/cloudflared/config.yml run
```

### cloudflared config.yml format

```yaml
tunnel: <tunnel-uuid>
credentials-file: /path/to/credentials.json

ingress:
  - hostname: yourdomain.com
    service: http://localhost:8642
  - hostname: '*.yourdomain.com'
    service: http://localhost:8642
  - service: http_status:404
```

**Critical:** `tunnel:` field is required when using a credentials file. Without it, cloudflared errors: `"cloudflared tunnel run" requires the ID or name of the tunnel`.

**Token format gotcha**

| Token prefix | Type | Works with `tunnel run --token`? |
|---|---|---|
| `cfut_` | Unified Tunnel token | Yes |
| `cfat_` | Cloudflare Access API token | No — for API calls only |

If only a `cfat_` token is available, create the tunnel via API (which returns a credentials file) rather than using `tunnel run --token`.

> **Live reference:** `references/cloudflared-tunnel-setup.md` — working end-to-end session transcript with verified config.yml contents, credentials.json structure, and Cloudflare API endpoint inventory.

## Terraform Workflow

### Initialize

```bash
ssh -o StrictHostKeyChecking=no sean@localhost "cd /home/sean/.hermes/agent-os/infra/terraform && ~/.local/bin/terraform init"
```

### Plan

```bash
ssh -o StrictHostKeyChecking=no sean@localhost "cd /home/sean/.hermes/agent-os/infra/terraform && TF_VAR_cloudflare_api_token=<token> TF_VAR_cloudflare_account_id=<id> TF_VAR_zone_id=<zone> TF_VAR_tunnel_secret=<secret> ~/.local/bin/terraform plan"
```

### Apply

```bash
ssh -o StrictHostKeyChecking=no sean@localhost "cd /home/sean/.hermes/agent-os/infra/terraform && TF_VAR_cloudflare_api_token=<token> TF_VAR_cloudflare_account_id=<id> TF_VAR_zone_id=<zone> TF_VAR_tunnel_secret=<secret> ~/.local/bin/terraform apply"
```

## Cloudflare API Token Scopes

Required for Terraform:
- `Account: Tunnel: Edit`
- `Zone: DNS: Edit`
- `Access: Organisations: Read`
- `Access: Applications: Edit`

## Terraform State

Never commit `.tfstate` to git. State is stored locally on the host at:
`/home/sean/.hermes/agent-os/infra/terraform/.terraform/terraform.tfstate`

## Secrets Management

- Cloudflare API token: set via `TF_VAR_cloudflare_api_token` env var
- Tunnel secret: set via `TF_VAR_tunnel_secret` env var
- Never hardcode in `.tfvars` files committed to git

## GitOps Pattern for agent-os

1. Terraform files live in `infra/terraform/` (committed to GitHub)
2. `.tfvars` with real secrets stay on host ONLY (in `.gitignore`)
3. GitHub Actions does NOT run terraform (no credentials in GitHub)
4. Terraform apply runs locally on host when needed
5. Cloudflare tunnel credentials written directly to `~/.cloudflared/`
