---
name: deployment-patterns
description: Deployment workflows, CI/CD pipelines, Docker containerization, health checks, rollback strategies, and production readiness checklists.
origin: ECC (adapted for Hermes)
---

# Deployment Patterns

Production deployment workflows and CI/CD best practices.

## When to Activate

- Setting up CI/CD pipelines (GitHub Actions)
- Dockerizing an application for production
- Planning deployment strategy (rolling, blue-green, canary)
- Implementing health checks and readiness probes
- Preparing for a production release

## Deployment Strategies

### Rolling (Default for agent-os)
Replace containers gradually. Zero downtime, backward-compatible changes required.

### Blue-Green
Two identical environments, switch traffic atomically. Instant rollback. Requires 2x infra.

### Canary (hermes-web-computer)
Route small % traffic to new version first. Catches issues before full rollout.

## Multi-Stage Dockerfiles

### Node.js (agent-os)
```dockerfile
FROM node:22-alpine AS deps
WORKDIR /app
COPY package.json package-lock.json ./
RUN npm ci --production=false

FROM node:22-alpine AS builder
WORKDIR /app
COPY --from=deps /app/node_modules ./node_modules
COPY . .
RUN npm run build

FROM node:22-alpine AS runner
WORKDIR /app
RUN addgroup -g 1001 -S app && adduser -S app -u 1001
USER app
COPY --from=builder --chown=app:app /app/node_modules ./node_modules
COPY --from=builder --chown=app:app /app/dist ./dist
ENV NODE_ENV=production
HEALTHCHECK --interval=30s --timeout=3s --start-period=5s --retries=3 \
  CMD wget -qO- http://localhost:3000/health || exit 1
CMD ["node", "dist/server.js"]
```

### Go (hermes-web-computer backend)
```dockerfile
FROM golang:1.22-alpine AS builder
WORKDIR /app
COPY go.mod go.sum ./
RUN go mod download
COPY . .
RUN CGO_ENABLED=0 GOOS=linux go build -ldflags="-s -w" -o /server ./cmd/server

FROM alpine:3.19 AS runner
RUN apk --no-cache add ca-certificates
RUN adduser -D -u 1001 appuser
USER appuser
COPY --from=builder /server /server
EXPOSE 8080
HEALTHCHECK --interval=30s --timeout=3s CMD wget -qO- http://localhost:8080/health || exit 1
CMD ["/server"]
```

## CI/CD Pipeline (GitHub Actions)

```yaml
name: Deploy
on:
  push:
    branches: [main]

jobs:
  build:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - name: Build & Push
        run: |
          docker build -t ghcr.io/${{ github.repository }}:${{ github.sha }} .
          echo "${{ secrets.GITHUB_TOKEN }}" | docker login ghcr.io -u $GITHUB_ACTOR --password-stdin
          docker push ghcr.io/${{ github.repository }}:${{ github.sha }}

  deploy:
    needs: build
    runs-on: ubuntu-latest
    steps:
      - name: SSH Deploy
        uses: appleboy/ssh-action@v1
        with:
          host: ${{ secrets.DEPLOY_HOST }}
          key: ${{ secrets.DEPLOY_KEY }}
          script: |
            cd /opt/app
            docker pull ghcr.io/${{ github.repository }}:${{ github.sha }}
            docker compose up -d --force-recreate
            sleep 5
            curl -f http://localhost:3000/health || exit 1
```

## Health Checks

- **HTTP endpoint**: `/health` returning 200 with body `{"status":"ok"}`
- **Readiness probe**: checks dependencies (DB, Redis, etc.)
- **Liveness probe**: process is alive (simple 200)
- **Interval**: 30s, timeout 3s, retries 3, start-period 5s

## Rollback Strategy

1. Keep previous image tag available
2. `docker compose up -d --force-recreate` with previous tag
3. Verify health endpoint
4. If rollback fails, alert via Telegram/Discord

## Pre-Deploy Checklist

- [ ] All tests pass
- [ ] No security vulnerabilities (npm audit / gosec)
- [ ] Docker image builds successfully
- [ ] Health endpoint works locally
- [ ] Environment variables documented
- [ ] Database migrations tested (if any)
- [ ] Rollback plan verified
