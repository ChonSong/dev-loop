---
name: repo-init
description: "Initialize a new project repository from scratch: monorepo scaffolding (turbo + nx), Docker setup, CI/CD pipeline (GitHub Actions + path filtering + semantic release), PostgreSQL (Neon), and secrets management. Used when creating net-new projects under ChonSong."
version: 1.0.0
author: Hermes Agent
license: MIT
metadata:
  hermes:
    tags: [repo-creation, monorepo, docker, github-actions, terraform, neon]
    track: infrastructure
    project: agent-os
---

# repo-init — New Project Repository Initialization

Create a production-ready open-source repository from scratch. Applies to ChonSong net-new projects. For existing repo migrations, see `repo-discovery` + `github-repo-management`.

## Trigger Conditions

- User asks to create a new repo (e.g., "create a new project called X")
- Roadmap task type is `setup` for a new repo
- A project migrates from a scaffold to a production-ready monorepo

## Architecture Decisions (Established 2026-05-01)

These are not arbitrary — they reflect hard lessons from `agent-os` and previous projects:

| Decision | Choice | Rationale |
|----------|--------|-----------|
| Repo name | Descriptive, not clever | `agent-os` beats `claw-v2` |
| Monorepo tool | Turbo + Nx dual config | Turbo for task scheduling, Nx for Go/WSL support |
| Docker strategy | Individual Dockerfiles per app | `dashboard-frontend`, `dashboard-backend`, `agent-core` |
| CI trigger | Path-filtered per project | Avoids running Python tests on Go-only changes |
| Release | Semantic release + conventional commits | `feat:`, `fix:`, `chore:` prefix required |
| PostgreSQL | Neon (serverless) | Free tier, no self-hosting, connection string in secrets |
| Secrets | GitHub Actions secrets + `.env.example` | Never commit secrets, always provide `.env.example` |
| Git history | Fresh start | Do NOT bring git history into migrated packages |

## Step-by-Step

### Step 1: Create GitHub Repo

```python
import urllib.request, json

GH_TOKEN = "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"  # ChonSong token
repo_name = "agent-os"
description = "Autonomous agent operating system for dashboard ecosystems"

req = urllib.request.Request(
    "https://api.github.com/user/repos",
    data=json.dumps({"name": repo_name, "description": description, "private": False}).encode(),
    headers={"Authorization": f"token {GH_TOKEN}", "Accept": "application/vnd.github.v3+json"},
    method="POST"
)
with urllib.request.urlopen(req) as r:
    print(json.loads(r.read())["html_url"])
```

### Step 2: Clone Empty Repo

```bash
git clone https://github.com/ChonSong/{repo_name}.git /opt/data/{repo_name}
cd /opt/data/{repo_name}
git config user.email "seanos1a@gmail.com"
git config user.name "Sean"
```

### Step 3: Scaffold Monorepo Structure

```
{repo_name}/
├── apps/
│   └── dashboard/
│       ├── frontend/        # Vite + React + TypeScript
│       └── backend/         # Express + Socket.io
├── packages/
│   └── shared-types/        # TypeScript types (published to GitHub Packages)
├── infra/
│   └── CasaOS/
│       ├── agent/
│       └── webhook-emitter/
├── .github/workflows/
│   ├── ci.yml               # Path-filtered: python/node/go jobs
│   ├── release.yml          # Semantic release on main merge
│   └── deploy.yml           # Docker build + push on release
├── turbo.json               # Turborepo config
├── nx.json                  # Nx + @nx-go plugin
├── pyproject.toml           # Python workspace root
├── go.mod                   # Go module root
└── SPEC.md                  # Architecture spec + schema
```

### Step 4: Add CI/CD

**`.github/workflows/ci.yml`** — path-filtered matrix:

```yaml
name: CI
on: [push, pull_request]
jobs:
  python:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: actions/setup-python@v5
        with: { python-version: '3.11' }
      - run: pip install -e packages/observability/
      - run: python -m pytest packages/observability/tests/ -v
        continue-on-error: true  # remove when tests exist

  node:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: actions/setup-node@v4
        with: { node-version: '20' }
      - run: npm install
      - run: npm run build --workspace=apps/dashboard/frontend
        continue-on-error: true

  go:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - run: go build ./...
        working-directory: infra/CasaOS/agent
        continue-on-error: true  # remove when go files exist
```

**`.github/workflows/release.yml`** — semantic release:

```yaml
name: Release
on:
  push:
    branches: [main]
jobs:
  release:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: actions/setup-node@v4
        with: { node-version: '20', registry-url: 'https://npm.pkg.github.com' }
        env: { NODE_AUTH_TOKEN: ${{ secrets.GITHUB_TOKEN }} }
      - run: npm install
      - run: npx semantic-release
        env: { GITHUB_TOKEN: ${{ secrets.GITHUB_TOKEN }} }
```

### Step 5: Add Docker Support

**`apps/dashboard/frontend/Dockerfile`:**
```dockerfile
FROM node:20-alpine AS build
WORKDIR /app
COPY package*.json ./
RUN npm install
COPY . .
RUN npm run build

FROM nginx:alpine
COPY --from=build /app/dist /usr/share/nginx/html
EXPOSE 80
```

**`apps/dashboard/backend/Dockerfile`:**
```dockerfile
FROM node:20-alpine
WORKDIR /app
COPY package*.json ./
RUN npm install --omit=dev
COPY . .
EXPOSE 3001
CMD ["node", "dist/index.js"]
```

### Step 6: Add PostgreSQL (Neon) Schema Reference

In `SPEC.md`:
```markdown
## Database

PostgreSQL via **Neon** (serverless, free tier).

### Schema

```sql
-- Sessions
CREATE TABLE sessions (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id TEXT NOT NULL,
  started_at TIMESTAMPTZ DEFAULT NOW(),
  ended_at TIMESTAMPTZ,
  metadata JSONB DEFAULT '{}'
);

-- AIE Events (journal)
CREATE TABLE aie_events (
  id SERIAL PRIMARY KEY,
  session_id UUID REFERENCES sessions(id),
  type TEXT NOT NULL,  -- delegation | tool_call | assumption | drift | circuit_open | task_complete
  timestamp TIMESTAMPTZ DEFAULT NOW(),
  data JSONB NOT NULL
);

-- Drift log
CREATE TABLE drift_log (
  id SERIAL PRIMARY KEY,
  session_id UUID REFERENCES sessions(id),
  assumption TEXT NOT NULL,
  correction TEXT NOT NULL,
  corrected_at TIMESTAMPTZ DEFAULT NOW()
);
```

**Connection:** `NEON_DATABASE_URL` stored as GitHub Actions secret, injected via `deploy.yml`.
```

### Step 7: Push Initial Commit

```bash
git add .
git commit -m "feat: initial scaffold"
git remote add origin https://github.com/ChonSong/{repo_name}.git
git push -u origin main
```

## Patterns That Work

- **`|| true` guards in CI** — allow empty packages to pass CI until real code lands; remove guards as tasks complete
- **Path filtering via `needs: [changes]`** — matrix job outputs which paths changed; downstream jobs skip if their path wasn't touched
- **Individual Dockerfiles per app** — avoids building entire monorepo for a single app change; tags as `dashboard-frontend`, `dashboard-backend`, `agent-core`
- **Python editable install in CI** — `pip install -e .` lets tests import the package without publishing
- **`SPEC.md` as living architecture doc** — written at repo creation, updated with each major feature

## Anti-Patterns to Avoid

- **Single monolith Dockerfile** — rebuilds everything on any change
- **Committing `node_modules/` or `__pycache__/`** — add to `.gitignore` at creation
- **Secrets in env vars committed to repo** — always use `.env.example` with placeholder values
- **Git history in migrated packages** — fresh start; history stays in the source repo (e.g., HKUDS/nanobot)
- **Path deps in `requirements.txt`** — use `git+https://github.com/ChonSong/...` or `pip install -e git+...` for Docker compatibility

## Secrets Checklist (before first release)

- [ ] `NEON_DATABASE_URL` — Neon connection string
- [ ] `CLOUDFLARE_API_TOKEN` — if using Cloudflare tunnels
- [ ] `DOCKER_HUB_TOKEN` — if pushing to Docker Hub
- [ ] `GITHUB_TOKEN` — provided automatically, use for npm GitHub Packages auth

## References

See `references/agent-os-creation.md` — full agent-os repo creation transcript (2026-05-01): exact commands, decisions made, CI output, and task queue.
