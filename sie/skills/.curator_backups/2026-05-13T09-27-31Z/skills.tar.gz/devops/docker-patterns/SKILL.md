---
name: docker-patterns
description: Docker and Docker Compose patterns for local dev, container security, networking, volume strategies, and multi-service orchestration. Complements hermes-docker-workflow.
origin: ECC (adapted for Hermes)
---

# Docker Patterns

Docker and Docker Compose best practices for containerized development. Complements `hermes-docker-workflow` (which covers Hermes-specific container management).

## When to Activate

- Setting up Docker Compose for local development
- Designing multi-container architectures
- Troubleshooting container networking or volume issues
- Reviewing Dockerfiles for security and size
- Writing multi-stage Dockerfiles for production

## Docker Compose for Local Development

### Standard Web App Stack

```yaml
services:
  app:
    build:
      context: .
      target: dev                     # Use dev stage of multi-stage Dockerfile
    ports:
      - "3000:3000"
    volumes:
      - .:/app                        # Bind mount for hot reload
      - /app/node_modules             # Anonymous volume -- preserves container deps
    environment:
      - DATABASE_URL=postgres://postgres:pass@db:5432/app_dev
      - REDIS_URL=redis://redis:6379/0

  db:
    image: postgres:16-alpine
    volumes:
      - pgdata:/var/lib/postgresql/data
    environment:
      - POSTGRES_PASSWORD=pass

volumes:
  pgdata:
```

### Custom Networks (isolation)

```yaml
services:
  frontend:
    networks: [frontend-net]
  api:
    networks: [frontend-net, backend-net]
  db:
    networks: [backend-net]           # Only reachable from api, not frontend

networks:
  frontend-net:
  backend-net:
```

### Exposing Only What's Needed

```yaml
services:
  db:
    ports:
      - "127.0.0.1:5432:5432"        # Only accessible from host
    # Omit ports entirely in production -- accessible only within Docker network
```

## Volume Strategies

| Type | Use Case | Example |
|------|----------|---------|
| Named volume | Persistent data | `pgdata:/var/lib/postgresql/data` |
| Bind mount | Hot reload (dev) | `./src:/app/src` |
| Anonymous volume | Protect container content from bind override | `/app/node_modules` |

## Dockerfile Best Practices

### Multi-Stage (Node.js)

```dockerfile
FROM node:22-alpine AS deps
WORKDIR /app
COPY package.json package-lock.json ./
RUN npm ci --production=false

FROM node:22-alpine AS builder
WORKDIR /app
COPY --from=deps /app/node_modules ./node_modules
COPY . .
RUN npm run build

FROM node:22-alpine AS runner
WORKDIR /app
RUN addgroup -g 1001 -S app && adduser -S app -u 1001
USER app
COPY --from=builder --chown=app:app /app/node_modules ./node_modules
COPY --from=builder --chown=app:app /app/dist ./dist
ENV NODE_ENV=production
EXPOSE 3000
HEALTHCHECK --interval=30s --timeout=3s --start-period=5s --retries=3 \
  CMD wget -qO- http://localhost:3000/health || exit 1
CMD ["node", "dist/server.js"]
```

### Multi-Stage (Go)

```dockerfile
FROM golang:1.22-alpine AS builder
WORKDIR /app
COPY go.mod go.sum ./
RUN go mod download
COPY . .
RUN CGO_ENABLED=0 GOOS=linux go build -ldflags="-s -w" -o /server ./cmd/server

FROM alpine:3.19 AS runner
RUN apk --no-cache add ca-certificates
RUN adduser -D -u 1001 appuser
USER appuser
COPY --from=builder /server /server
EXPOSE 8080
HEALTHCHECK --interval=30s --timeout=3s CMD wget -qO- http://localhost:8080/health || exit 1
CMD ["/server"]
```

## Container Security

- Use specific tags (never `:latest`)
- Run as non-root user
- Drop all capabilities, add only what's needed
- Read-only root filesystem where possible
- No secrets in image layers — use env vars or Docker secrets
- `.dockerignore`: `node_modules .git .env dist coverage *.log`

## Anti-Patterns

- **Running as root** — always create non-root user
- **Using `:latest` tag** — pin to specific versions
- **Storing data without volumes** — containers are ephemeral
- **One giant container** — one process per container
- **Hardcoded secrets in compose** — use `.env` files (gitignored)
- **No healthchecks** — always add HEALTHCHECK for production services
