---
name: go
description: Build, test, and run Go projects on the host system. Covers module initialization, dependency management, cobra CLI patterns, cross-compilation, and Docker multi-stage builds for Go binaries.
tags: ["go", "golang", "cli", "cobra", "docker"]
---

# Go Development

## Host Environment

Go 1.25 is installed in both the hermes container (at `/usr/lib/go-1.25`) AND on the host.
- **Container**: `cd /opt/data/hermes-web-computer/backend && go build ./...`
- **Host**: `ssh -o StrictHostKeyChecking=no sean@localhost "cd /path/to/module && go build ./..."`

### Linter false positives

The Go linter in the container often reports `no required module provides package X` even when `go build ./...` succeeds. This is because the linter runs without full module context. **Trust `go build` and `go vet` over the linter.**

## PTY Pattern (creack/pty)

When using `github.com/creack/pty`, **do not read from the PTY file descriptor in multiple goroutines** — only one reader will get the data. The fix is to add an output channel to the session:

```go
type PTYSession struct {
    PTY    *os.File
    Output chan []byte  // Single consumer reads from this
    mu     sync.Mutex
}

// In Start():
go func() {
    buf := make([]byte, 4096)
    for {
        n, err := p.Read(buf)
        if err != nil { return }
        session.mu.Lock()
        session.RingBuf.Write(buf[:n])  // Ring buffer for checkpoint
        session.mu.Unlock()
        // Forward to output channel (non-blocking)
        data := make([]byte, n)
        copy(data, buf[:n])
        select {
        case session.Output <- data:
        default: // Drop if channel full
        }
    }
}()

// Consumer reads from session.Output, not from session.PTY
```

## Common Patterns

### Initialize a new Go module

```bash
ssh -o StrictHostKeyChecking=no sean@localhost "cd /path/to/module && go mod init module/path && go get github.com/spf13/cobra@v1 && go mod tidy"
```

### Build a Go package

```bash
ssh -o StrictHostKeyChecking=no sean@localhost "cd /path/to/module && go build -o /tmp/bin-name ."
```

### Run tests

```bash
ssh -o StrictHostKeyChecking=no sean@localhost "cd /path/to/module && go test ./..."
```

### Create a cobra CLI

```go
package main

import (
    "fmt"
    "github.com/spf13/cobra"
)

func main() {
    root := &cobra.Command{Use: "myapp"}
    root.AddCommand(&cobra.Command{
        Use:   "subcommand",
        Short: "Does something",
        RunE:  runSubcommand,
    })
    if err := root.Execute(); err != nil {
        panic(err)
    }
}

func runSubcommand(cmd *cobra.Command, args []string) error {
    fmt.Println("Running subcommand")
    return nil
}
```

### Docker multi-stage build for Go

```dockerfile
# Stage 1: build
FROM golang:1.22-alpine AS builder
WORKDIR /src
COPY go.mod go.sum ./
RUN go mod download
COPY *.go .
RUN CGO_ENABLED=0 GOOS=linux go build -o /bin/myapp .

# Stage 2: runtime
FROM alpine:latest
COPY --from=builder /bin/myapp /usr/local/bin/
ENTRYPOINT ["myapp"]
```

## Path Conventions

- Go modules live under `/home/sean/.hermes/agent-os/infra/CasaOS/agent/` and `.../webhook-emitter/`
- Build outputs to `/tmp/` for testing, or to the module dir for final binaries
- Go module cache: `~/.cache/go-build`
