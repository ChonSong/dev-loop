---
name: git-workflow
description: Git workflow patterns — branching strategies, conventional commits, merge vs rebase, conflict resolution, PR summaries, and clean history.
origin: ECC (adapted for Hermes)
---

# Git Workflow

Git conventions for clean, traceable, professional repositories.

## When to Activate

- Starting a new feature or fix
- Writing commit messages
- Resolving merge conflicts
- Preparing a PR
- Cleaning up messy history

## Branch Strategy

```
main ──────────────────────────────────── (production)
  ├── feat/feature-name                  (new features)
  ├── fix/bug-description                (bug fixes)
  ├── refactor/description               (code cleanup)
  └── chore/description                  (maintenance)
```

## Conventional Commits

```
<type>: <description>

feat: add user authentication
fix: resolve race condition in webhook handler
refactor: extract payment logic into service
docs: update API documentation
test: add integration tests for checkout flow
chore: update dependencies
perf: optimize image loading
ci: add deployment pipeline
```

### Breaking Changes

```
feat: change authentication method

BREAKING CHANGE: Switch from session-based to JWT auth.
All clients must update to include Authorization header.
```

## PR Best Practices

- **Title**: Conventional commit format
- **Description**: What changed, why, how to test
- **Small PRs**: One logical change per PR
- **Link issues**: `Closes #123`
- **Review checklist**: Tests pass, no security issues, docs updated

## Rebase vs Merge

| Scenario | Use |
|----------|-----|
| Feature branch → main | Squash merge (clean history) |
| Sync main into feature | Rebase (linear history) |
| Hotfix to main | Direct commit + cherry-pick |
| Multiple PRs in sequence | Rebase each onto main |

## Conflict Resolution

1. `git fetch origin`
2. `git rebase origin/main`
3. Resolve conflicts in each file
4. `git add <resolved-files>`
5. `git rebase --continue`
6. `git push --force-with-lease` (if rebasing pushed branch)

## Divergent Branch Recovery

When local and remote have diverged (possibly with unrelated histories), and normal `git pull --rebase` fails:

```bash
# Scenario: local has commits, remote has different commits, git pull fails
git fetch origin
git reset --hard origin/main   # Discard local commits that conflict
# Re-apply your changes:
git add -A
git commit -m "your changes"
git push                       # Normal push now works

# If that's too destructive and you want to keep local work:
git stash
git pull origin main --no-rebase --allow-unrelated-histories
git stash pop
git add -A && git commit --amend --no-edit
git push --force-with-lease    # Requires approval
```

**Key insight:** When `git pull --rebase` fails with "unrelated histories" and `git merge` also fails, `git push --force-with-lease` is the fastest path forward — it overwrites the remote with your version while protecting against concurrent pushes by other collaborators.

## Clean History

- Squash WIP commits before merging
- Use `git commit --amend` for typos in last commit
- `git log --oneline --graph` to review history
- Never rewrite public/main branch history

## Hermes Adaptation

- All commits from Hermes use conventional commits
- PR summaries include: changes, testing notes, screenshots (if UI)
- When pushing from container: `ssh -i /opt/data/container_key sean@localhost "cd /path && git ..."`
- For agent-os: commits go to `ChonSong/agent-os` main branch
